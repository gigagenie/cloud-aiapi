package kt.gigagenie.ai.api;

public interface STTgRPCCallback {
    void onConnectGRPC();
    void onSTTResult(String text, String type, float startTime, float endTime);
    void onReadySTT(int sampleRate, int channel, String format);
    void onStopSTT();
    void onRelease();
    void onError(int errCode, String errMsg);
}
