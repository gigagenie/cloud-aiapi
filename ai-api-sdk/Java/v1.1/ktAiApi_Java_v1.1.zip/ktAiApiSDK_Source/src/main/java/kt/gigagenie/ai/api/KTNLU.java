package kt.gigagenie.ai.api;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * HTTP를 이용한 지니 Voice 처리 AI SDK API 제공 클래스
 * 
 * @author ALGOGRAP
 * @since 2023. 01. 25
 * @see
 * 
 *      <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2023.01.25    ALGOGRAP      최초생성
 *      </pre>
 */
public class KTNLU {

	/** KTNLU voice Synthesis URL */
	private final String URL_KTNLU_WORKSPACESERVICE = "/v2/ktnlu/workspaceService";
	
	private final String URL_KTNLU_NERSERVICE = "/v2/ktnlu/nerService";

	/** service url */
	private String mServiceURL;

	/** clientKey */
	private String mClientKey;

	/** timestamp */
	private String mTimeStamp;

	/** signature */
	private String mSignature;

	/**
	 * Creates a new KTNLU.
	 */
	public KTNLU() {
		HttpUtils.checkEntryPointProfile();
	}

	/**
	 * Sets Auth Information of KTNLU.
	 *
	 * @param clientKey    the value of the API Key.
	 * @param clientId     the value of the client id.
	 * @param clientSecret the value of the client secret.
	 *
	 */
	public void setAuth(String clientKey, String clientId, String clientSecret) {
		if (HttpUtils.isEmpty(clientKey)) {
			return;
		}

		this.mClientKey = clientKey;

		if (!HttpUtils.isEmpty(clientId) && !HttpUtils.isEmpty(clientSecret)) {
			this.mTimeStamp = HttpUtils.getTimestamp();
			this.mSignature = HttpUtils.makeSignature(mTimeStamp, clientId, clientSecret);
		}
	}

	/**
	 * Sets URL Information of service.
	 *
	 * @param endpoint the URL Information of service.
	 *
	 */
	public void setServiceURL(String endpoint) {
		HttpUtils.setHttpEntrypoint(endpoint);
	}

	public JSONObject requestWORKSPACESERVICE(final int domain, String message, int intentLimit, String freeTrial) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("domain", domain);
				metadataJsonObject.put("message", message);
				metadataJsonObject.put("intentLimit", intentLimit);
				metadataJsonObject.put("freeTrial", freeTrial);

//				if (encoding.equalsIgnoreCase("wav")) {
//					JSONObject encodingOptObject = new JSONObject();
//					encodingOptObject.put("channel", channel);
//					encodingOptObject.put("sampleRate", sampleRate);
//					encodingOptObject.put("sampleFmt", sampleFmt);
//
//					metadataJsonObject.put("encodingOpt", encodingOptObject);
//				}

				String strUrl = mServiceURL + URL_KTNLU_WORKSPACESERVICE;
				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestPost(strUrl, jsonObject, metaData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {

				}
				return resultJson;
			}
		}
	}
		
		public JSONObject requestNERSERVICE(final String message, int intentLimit, String freeTrial) {
			synchronized (this) {
				JSONObject resultJson = new JSONObject();

				try {
					mServiceURL = HttpUtils.getHttpEntrypointUrl();

					JSONObject metadataJsonObject = new JSONObject();
					metadataJsonObject.put("message", message);
					metadataJsonObject.put("intentLimit", intentLimit);
					metadataJsonObject.put("freeTrial", freeTrial);

//					if (encoding.equalsIgnoreCase("wav")) {
//						JSONObject encodingOptObject = new JSONObject();
//						encodingOptObject.put("channel", channel);
//						encodingOptObject.put("sampleRate", sampleRate);
//						encodingOptObject.put("sampleFmt", sampleFmt);
	//
//						metadataJsonObject.put("encodingOpt", encodingOptObject);
//					}

					String strUrl = mServiceURL + URL_KTNLU_NERSERVICE;
					String metaData = metadataJsonObject.toString();

					JSONObject jsonObject = new JSONObject();
					if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
						jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
						jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
						jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
					} else {
						jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
					}

					return (JSONObject) HttpUtils.requestPost(strUrl, jsonObject, metaData);
				} catch (Exception e) {
					try {
						resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
						resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
					} catch (JSONException e1) {

					}
					return resultJson;
				}
			}
	}
}
