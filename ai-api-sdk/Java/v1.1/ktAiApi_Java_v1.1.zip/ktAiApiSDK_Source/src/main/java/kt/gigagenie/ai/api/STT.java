package kt.gigagenie.ai.api;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * HTTP를 이용한 지니 Dictation 처리 AI SDK API 제공 클래스
 * 
 * @author KT AI연구소
 * @since 2021. 02. 01
 * @see
 * 
 *      <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2021.02.01   KT AI연구소      최초생성
 *   2022.09.27   KT AI연구소      수정사항 적용
 *      </pre>
 */
public class STT {

	/** STT voice Recognize URL */
	private final String URL_STT_VOICE_RECOGNIZER = "/v2/voiceRecognize";
	private final String URL_STT_VOICE_RECOGNIZER2 = "/v2/voiceRecognize2";

	/** Service url */
	private String mServiceURL;

	/** ClientKey */
	private String mClientKey;

	/** Timestamp */
	private String mTimeStamp;

	/** Signature */
	private String mSignature;

	/**
	 * Creates a new STT.
	 */
	public STT() {
		HttpUtils.checkEntryPointProfile();
	}

	/**
	 * Sets Auth Information of STT.
	 *
	 * @param clientKey    the value of the API Key.
	 * @param clientId     the value of the client id.
	 * @param clientSecret the value of the client secret.
	 *
	 */
	public void setAuth(String clientKey, String clientId, String clientSecret) {
		if (HttpUtils.isEmpty(clientKey)) {
			return;
		}

		this.mClientKey = clientKey;

		if (!HttpUtils.isEmpty(clientId) && !HttpUtils.isEmpty(clientSecret)) {
			this.mTimeStamp = HttpUtils.getTimestamp();
			this.mSignature = HttpUtils.makeSignature(mTimeStamp, clientId, clientSecret);
		}
	}

	/**
	 * Sets URL Information of service.
	 *
	 * @param endpoint the URL Information of service.
	 *
	 */
	public void setServiceURL(String endpoint) {
		HttpUtils.setHttpEntrypoint(endpoint);
	}

	/**
	 * Sends a audio data to convert to Text.
	 *
	 * @param audioData      a byte array with the audio data.
	 * @param sttMode        The mode of STT Operation.
	 * @param targetLanguage target language of the audio data (ex, "ko").
	 * @param encoding       encoding method of the audio data (ex, "raw", "wav", "mp3", "vor", "aac", "fla").
	 * @param channel        channel type of the audio data (ex, Mono: 1, Stereo: 2).
	 * @param sampleRate     sampling rate type of the audio data (ex, 16000, 44100, 48000).
	 * @param sampleFmt      sampling format type of the audio data (ex, "S16LE": signed 16bit little endian, "F32LE": float 32bit little endian).
	 *
	 * @return a JSONObject with the STT result data.
	 */
	public JSONObject requestSTT(final byte[] audioData, int sttMode, String targetLanguage, String encoding, int channel, int sampleRate, String sampleFmt) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("encoding", encoding);
				metadataJsonObject.put("targetLanguage", targetLanguage);
				metadataJsonObject.put("sttMode", sttMode);

				if (encoding.equalsIgnoreCase("raw")) {
					JSONObject encodingOptObject = new JSONObject();
					encodingOptObject.put("channel", channel);
					encodingOptObject.put("sampleRate", sampleRate);
					encodingOptObject.put("sampleFmt", sampleFmt);

					metadataJsonObject.put("encodingOpt", encodingOptObject);
				}

				String strUrl = mServiceURL + URL_STT_VOICE_RECOGNIZER;
				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestMutipart(strUrl, jsonObject, metaData, audioData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {
				}
				return resultJson;
			}
		}
	}
	
	/**
	 * Sends a audio data to convert to Text.
	 *
	 * @param audioData      a byte array with the audio data.
	 * @param encoding       encoding method of the audio data (ex, "raw", "wav", "mp3", "vor", "aac", "fla").
	 * @param sttModelCode   The mode of STT Operation.
	 *
	 * @return a JSONObject with the STT result data.
	 */
	public JSONObject requestSTT2(final byte[] audioData, String encoding, int sttModelCode) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("encoding", encoding);
				metadataJsonObject.put("sttModelCode", sttModelCode);

				String strUrl = mServiceURL + URL_STT_VOICE_RECOGNIZER2;
				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestMutipart(strUrl, jsonObject, metaData, audioData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {
				}
				return resultJson;
			}
		}
	}

	/**
	 * Query if there is any converted Text.
	 *
	 * @param transactionId transaction id that received sendAudioData result.
	 *
	 * @return a JSONObject with the STT result data.
	 */
	public JSONObject querySTT(final String transactionId) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				String strUrl = mServiceURL + URL_STT_VOICE_RECOGNIZER + "/" + transactionId;

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestGet(strUrl, jsonObject, "");
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {

				}
				return resultJson;
			}
		}
	}
}
