package kt.gigagenie.ai.api;

import com.google.protobuf.ByteString;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.Metadata;
import io.grpc.netty.GrpcSslContexts;
import io.grpc.netty.NettyChannelBuilder;
import io.grpc.stub.MetadataUtils;
import io.grpc.stub.StreamObserver;
import io.netty.handler.ssl.SslContext;
import io.netty.handler.ssl.SslContextBuilder;

import javax.net.ssl.SSLException;
import java.io.File;
import java.util.concurrent.TimeUnit;

import static io.grpc.Metadata.ASCII_STRING_MARSHALLER;

/**
 * GRPC를 이용한 Speech To Text 처리 AI SDK API 제공 클래스
 * 
 * @author KT AI연구소
 * @since 2021. 02. 01
 * @see
 * 
 *      <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2021.02.01   KT AI연구소      최초생성
 *   2022.09.27   KT AI연구소      수정사항 적용
 *      </pre>
 */

public class STTgRPC {

	private static final int GRPC_STATUS_DISCONNECTED = 0;
	private static final int GRPC_STATUS_CONNECTED = 1;
	private static final int GRPC_STATUS_STARTED = 2;
	private static final int GRPC_STATUS_STOPED = 3;

	/** gRPC Connection Status */
	private int mGrpcStatus;

	/** STTgRPCCallback event callback listener */
	private STTgRPCCallback mSTTgRPCCallback = null;

	/** ClientKey */
	private String mClientKey;

	/** Timestamp */
	private String mTimeStamp;

	/** Signature */
	private String mSignature;

	/** Requested SttMode for reconnection */
	private String mRequestSttMode;

	/** Requested SamleFmt for reconnection */
	private String mRequestSampleFmt;

	/** Requested SamleRate for reconnection */
	private int mRequestSampleRate;

	/** Requested Channel for reconnection */
	private int mRequestChannel;

	private int mRequeststtModelCode;

	/** SslContext */
	private SslContext mSslContext;

	/** gRPC Channel */
	private ManagedChannel mChannel;

	/** gRPC Async Stub */
	private KtAiApiGrpc.KtAiApiStub mAsyncStub;

	/** gRPC reqKtStt request handler */
	private StreamObserver<Ktaiapi.reqKtStt> mRequestObserver;

	/** gRPC reqKtStt response handler */
	private StreamObserver<Ktaiapi.resKtStt> mResponseObserver = new StreamObserver<Ktaiapi.resKtStt>() {
		@Override
		public void onNext(Ktaiapi.resKtStt value) {
			String msgType = "";
			String msgPayload = "";

			if (value.getSttResCase() == Ktaiapi.resKtStt.SttResCase.SIGNAL) {
				Ktaiapi.controlMsg msg = value.getSignal();
				msgType = msg.getMsgType();
				msgPayload = msg.getMsgPayload();
			}

			if (value.getSttResCase() == Ktaiapi.resKtStt.SttResCase.STTRESULT) {
				Ktaiapi.sttResultMsg sttMsg = value.getSttResult();
				if (mSTTgRPCCallback != null) {
					mSTTgRPCCallback.onSTTResult(sttMsg.getText(), sttMsg.getType(), sttMsg.getStartTime(), sttMsg.getEndTime());
				}
			}

			if (msgType.equalsIgnoreCase("sttStartRes")) {

			}

			if (msgType.equalsIgnoreCase("startSendPcmCmd")) {
				String Code = msgPayload.split(":")[0];
				if (Code.equalsIgnoreCase("CODE0200")) {
					String PcmFormat = msgPayload.split(":")[1];
					// F=S16LE, R=16000, C=1
					String format = PcmFormat.split(",")[0].substring("F=".length());
					String rate = PcmFormat.split(",")[1].substring("R=".length());
					String channel = PcmFormat.split(",")[2].substring("C=".length());
					int sampleRate = Integer.parseInt(rate);
					int ch = Integer.parseInt(channel);
					mGrpcStatus = GRPC_STATUS_STARTED;
					if (mSTTgRPCCallback != null) {
						mSTTgRPCCallback.onReadySTT(sampleRate, ch, format);
					}
				} else {
					if (mSTTgRPCCallback != null) {
						mSTTgRPCCallback.onError(getCode(Code), msgPayload);
					}
				}
			}

			if (msgType.equalsIgnoreCase("stopSendPcmCmd")) {
				stopSTT();
				if (mGrpcStatus != GRPC_STATUS_STOPED) {
					if (mSTTgRPCCallback != null) {
						mSTTgRPCCallback.onStopSTT();
					}
					mGrpcStatus = GRPC_STATUS_STOPED;
				}
			}

			if (msgType.equalsIgnoreCase("sttStopRes")) {
				if (mGrpcStatus != GRPC_STATUS_STOPED) {
					String Code = msgPayload.split(":")[0];
					if (mSTTgRPCCallback != null) {
						if (!Code.contains("200")) {
							mSTTgRPCCallback.onError(getCode(Code), msgPayload);
						}
						mSTTgRPCCallback.onStopSTT();
					}
					mGrpcStatus = GRPC_STATUS_STOPED;
				}
			}

			if (msgType.equalsIgnoreCase("sttEvent")) {

			}

			if (msgType.equalsIgnoreCase("errInfo")) {
				String Code = msgPayload.split(":")[0];
				if (mSTTgRPCCallback != null) {
					mSTTgRPCCallback.onError(getCode(Code), msgPayload);
				}
			}

		}

		@Override
		public void onError(Throwable t) {
			String msg = t.getMessage();
			t.printStackTrace();
			String strCode = "402";
			if (msg.contains("CODE:")) {
				strCode = msg.substring(msg.indexOf("CODE:") + "CODE:".length(), msg.indexOf(","));
			}
			String strMsg = "자원 없음 (음성인식 준비 안됨)";
			if (msg.contains("MSG:")) {
				strMsg = msg.substring(msg.indexOf("MSG:") + "MSG:".length());
			} else {
				strMsg += " [" + t.getMessage() + "]";
			}

			if (strMsg.contains("CODE0301:")) {
				String strEntryPoint = strMsg.split("entrypoint=")[1];

				if (!HttpUtils.isEmpty(strEntryPoint)) {
					HttpUtils.setGrpcEntrypoint(strEntryPoint);
					reconnectionGrpc();
					return;
				}
			}

			stopSTT();
			mGrpcStatus = GRPC_STATUS_STOPED;
			if (mSTTgRPCCallback != null) {
				mSTTgRPCCallback.onError(Integer.parseInt(strCode), strMsg);
			}
		}

		@Override
		public void onCompleted() {

		}
	};

	/**
	 * Creates a new STTgRPC
	 */
	public STTgRPC() {
		mSTTgRPCCallback = null;
		mGrpcStatus = GRPC_STATUS_DISCONNECTED;
		mSslContext = null;
		HttpUtils.checkEntryPointProfile();
	}

	/**
	 * Register STTgRPCCallback listener
	 *
	 * @param listener STTgRPCCallback listener.
	 *
	 */
	public void setSTTgRPCCallback(STTgRPCCallback listener) {
		synchronized (this) {
			mSTTgRPCCallback = listener;
		}
	}

	/**
	 * Sets Meta Information of STTgRPC.
	 *
	 * @param clientKey    the value of the API Key.
	 * @param clientId     the value of the client id.
	 * @param clientSecret the value of the client secret.
	 *
	 */
	public void setMetaData(String clientKey, String clientId, String clientSecret) {
		this.mClientKey = clientKey;
		this.mTimeStamp = HttpUtils.getTimestamp();
		this.mSignature = HttpUtils.makeSignature(mTimeStamp, clientId, clientSecret);
	}

	/**
	 * Sets the path of certificate.
	 *
	 * @param certPath the path of certificate.
	 *
	 */
	public void setSSL(String certPath) {
		try {
			mSslContext = null;
			if (!HttpUtils.isEmpty(certPath)) {
				final File file = new File(certPath);
				if (!file.exists()) {
					new Thread(new Runnable() {
						@Override
						public void run() {
							if (mSTTgRPCCallback != null) {
								mSTTgRPCCallback.onError(HttpUtils.RESULT_STATUS_CODE_401, "certPath의 파일이 존재하지 않음");
							}
						}
					}).start();
					return;
				}
				mSslContext = buildSslContext(certPath);
			}
		} catch (Exception e) {
			new Thread(new Runnable() {
				@Override
				public void run() {
					if (mSTTgRPCCallback != null) {
						mSTTgRPCCallback.onError(HttpUtils.RESULT_STATUS_CODE_401, "certificate 처리시 문제 발생.");
					}
				}
			}).start();
		}
	}

	/**
	 * Sets URL Information of service.
	 *
	 * @param endpoint the URL Information of service.
	 *
	 */
	public void setServiceURL(String endpoint) {
		HttpUtils.setGrpcEntrypoint(endpoint);
	}

	/**
	 * Connects to gRPC Server.
	 *
	 *
	 */
	public void connectGRPC() {
		if (mGrpcStatus != GRPC_STATUS_DISCONNECTED) {
			return;
		}

		new Thread(new Runnable() {
			@Override
			public void run() {

				connectToGrpc();

				mGrpcStatus = GRPC_STATUS_CONNECTED;
				if (mSTTgRPCCallback != null) {
					mSTTgRPCCallback.onConnectGRPC();
				}
			}
		}).start();
	}

	/**
	 * Release connection from gRPC Server.
	 *
	 */
	public void releaseConnection() {
		if (mGrpcStatus != GRPC_STATUS_STOPED && mGrpcStatus != GRPC_STATUS_CONNECTED) {
			return;
		}

		new Thread(new Runnable() {
			@Override
			public void run() {
				disConnectFromGrpc();
				mGrpcStatus = GRPC_STATUS_DISCONNECTED;
				if (mSTTgRPCCallback != null) {
					mSTTgRPCCallback.onRelease();
				}
			}
		}).start();
	}

	/**
	 * Starts gRPC STT Service.
	 * 
	 * @param sttMode    The mode of gRPC STT Operation.
	 * @param sampleFmt  sampling format type of the audio data (ex, "S16LE": signed 16bit little endian).
	 * @param sampleRate sampling rate type of the audio data (ex, 8000, 16000).
	 * @param channel    channel type of the audio data (ex, Mono: 1).
	 */
	public void startSTT(final String sttMode, final String sampleFmt, final int sampleRate, final int channel, final int sttModelCode) {
		mRequestSttMode = sttMode;
		mRequestSampleFmt = sampleFmt;
		mRequestSampleRate = sampleRate;
		mRequestChannel = channel;
		mRequeststtModelCode = sttModelCode;

		if (mGrpcStatus != GRPC_STATUS_STOPED && mGrpcStatus != GRPC_STATUS_CONNECTED) {
			return;
		}

		new Thread(new Runnable() {
			@Override
			public void run() {
				String msgPayload = "CODE0200:MODE=" + sttMode + ",F=" + sampleFmt + ",R=" + sampleRate + ",C=" + channel;
				final Ktaiapi.reqKtStt requestKtStt = Ktaiapi.reqKtStt.newBuilder().setSignal(Ktaiapi.controlMsg.newBuilder().setMsgType("sttStartCmd").setMsgPayload(msgPayload).build()).build();
				
				mRequestObserver = mAsyncStub.ktSttService(mResponseObserver);
				mRequestObserver.onNext(requestKtStt);
			}
		}).start();
	}

	/**
	 * Stops gRPC STT Service.
	 *
	 */
	public void stopSTT() {
		if (mGrpcStatus != GRPC_STATUS_STARTED) {
			return;
		}

		new Thread(new Runnable() {
			@Override
			public void run() {
				final Ktaiapi.reqKtStt requestKtStt = Ktaiapi.reqKtStt.newBuilder().setSignal(Ktaiapi.controlMsg.newBuilder().setMsgType("sttStopCmd").setMsgPayload("CODE0200:").build()).build();

				mRequestObserver.onNext(requestKtStt);
				mRequestObserver.onCompleted();
			}
		}).start();
	}

	/**
	 * Sends a audio data to convert to Text.
	 *
	 * @param audioData a byte array with the audio data.
	 *
	 */
	public void sendAudioData(byte[] audioData) {

		if (mGrpcStatus != GRPC_STATUS_STARTED) {
			return;
		}

		synchronized (this) {
			final Ktaiapi.reqKtStt requestKtStt = Ktaiapi.reqKtStt.newBuilder().setPcmData(ByteString.copyFrom(audioData)).build();

			mRequestObserver.onNext(requestKtStt);
		}
	}

	/**
	 * reconnection to gRPC Server.
	 *
	 */
	private void reconnectionGrpc() {
		new Thread(new Runnable() {
			@Override
			public void run() {
				disConnectFromGrpc();
				connectToGrpc();
				mGrpcStatus = GRPC_STATUS_CONNECTED;
				startSTT(mRequestSttMode, mRequestSampleFmt, mRequestSampleRate, mRequestChannel, mRequeststtModelCode);
			}
		}).start();
	}

	/**
	 * connect to gRPC Server.
	 *
	 */
	private void connectToGrpc() {
		final String host = HttpUtils.getGrpcEntrypoint();
		final int port = HttpUtils.getGrpcPort();

		if (mSslContext != null) {
			mChannel = NettyChannelBuilder.forAddress(host, port).useTransportSecurity().sslContext(mSslContext).build();
		} else {
			mChannel = ManagedChannelBuilder.forAddress(host, port).useTransportSecurity().build();
		}

		mAsyncStub = KtAiApiGrpc.newStub(mChannel);

		final Metadata.Key<String> X_CLIENT_KEY_HEADER_KEY = Metadata.Key.of(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, ASCII_STRING_MARSHALLER);
		final Metadata.Key<String> X_AUTH_TIMESTAMP_HEADER_KEY = Metadata.Key.of(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, ASCII_STRING_MARSHALLER);
		final Metadata.Key<String> X_CLIENT_SIGNATURE_HEADER_KEY = Metadata.Key.of(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, ASCII_STRING_MARSHALLER);

		// create a custom header
		Metadata header = new Metadata();

		/* put custom header */
		header.put(X_CLIENT_KEY_HEADER_KEY, mClientKey);
		header.put(X_AUTH_TIMESTAMP_HEADER_KEY, mTimeStamp);
		header.put(X_CLIENT_SIGNATURE_HEADER_KEY, mSignature);
		mAsyncStub = MetadataUtils.attachHeaders(mAsyncStub, header);
	}

	/**
	 * disconnect from gRPC Server.
	 *
	 */
	private void disConnectFromGrpc() {
		try {
			mChannel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
		} catch (Exception e) {

		}
	}

	/**
	 * Create SslContext for given certificate
	 *
	 * @param trustCertCollectionFilePath the path of certificate.
	 *
	 * @return SslContext
	 */
	private static SslContext buildSslContext(String trustCertCollectionFilePath) throws SSLException {
		SslContextBuilder builder = GrpcSslContexts.forClient();
		if (!HttpUtils.isEmpty(trustCertCollectionFilePath)) {
			builder.trustManager(new File(trustCertCollectionFilePath));
		}
		return builder.build();
	}

	/**
	 * Retrieves the value of code from gRPC CODE response string.
	 *
	 * @param strCode the gRPC CODE response string.
	 *
	 * @return the value of code
	 */
	private static int getCode(String strCode) {
		String strCodeValue = strCode.split("CODE")[1];
		int code = Integer.parseInt(strCodeValue);
		return code;
	}

	/**
	 * Retrieves the string of code descriptor from gRPC CODE response string.
	 *
	 * @param strCode the gRPC CODE response string.
	 *
	 * @return the string of code descriptor.
	 */
	private static String getCodeDescriptor(String strCode) {
		String strDescriptor = "";
		if (strCode.equalsIgnoreCase("CODE0200")) {
			strDescriptor = "성공";
		} else if (strCode.equalsIgnoreCase("CODE0500")) {
			strDescriptor = "서버 에러";
		} else if (strCode.equalsIgnoreCase("CODE0400")) {
			strDescriptor = "지원되지 않는 옵션임";
		} else if (strCode.equalsIgnoreCase("CODE0401")) {
			strDescriptor = "권한 없음";
		} else if (strCode.equalsIgnoreCase("CODE0402")) {
			strDescriptor = "자원 없음 (음성인식 준비 안됨)";
		} else {
			strDescriptor = "기타 에러";
		}

		return strDescriptor;
	}
}
