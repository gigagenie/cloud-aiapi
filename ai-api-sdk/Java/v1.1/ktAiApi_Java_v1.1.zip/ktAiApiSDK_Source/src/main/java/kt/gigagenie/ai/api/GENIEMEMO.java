package kt.gigagenie.ai.api;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * HTTP를 이용한 지니메모 처리 AI SDK API 제공 클래스
 * 
 * @author KT AI연구소
 * @since 2022. 09. 27
 * @see
 * 
 *      <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2022.09.27   KT AI연구소      최초생성
 *      </pre>
 */
public class GENIEMEMO {

	/** GENIEMEMO URL */
	private final String URL_GENIEMEMO = "/v2/genieMemo";

	/** GENIEMEMOASYNC URL */
	private final String URL_GENIEMEMOASYNC = "/v2/genieMemoAsync";

	/** GENIEMEMOQUERY URL */
	private final String URL_GENIEMEMOQUERY = "/v2/genieMemoQuery";

	/** Service url */
	private String mServiceURL;

	/** ClientKey */
	private String mClientKey;

	/** Timestamp */
	private String mTimeStamp;

	/** Signature */
	private String mSignature;

	/**
	 * Creates a new GenieMemo.
	 */
	public GENIEMEMO() {
		HttpUtils.checkEntryPointProfile();
	}

	/**
	 * Sets Auth Information of GenieMemo.
	 *
	 * @param clientKey    the value of the API Key.
	 * @param clientId     the value of the client id.
	 * @param clientSecret the value of the client secret.
	 *
	 */
	public void setAuth(String clientKey, String clientId, String clientSecret) {
		if (HttpUtils.isEmpty(clientKey)) {
			return;
		}

		this.mClientKey = clientKey;

		if (!HttpUtils.isEmpty(clientId) && !HttpUtils.isEmpty(clientSecret)) {
			this.mTimeStamp = HttpUtils.getTimestamp();
			this.mSignature = HttpUtils.makeSignature(mTimeStamp, clientId, clientSecret);
		}
	}

	/**
	 * Sets URL Information of service.
	 *
	 * @param endpoint the URL Information of service.
	 *
	 */
	public void setServiceURL(String endpoint) {
		HttpUtils.setHttpEntrypoint(endpoint);
	}

	/**
	 * Sends a audio data to convert to Text.
	 *
	 * @param audioData      a byte array with the audio data.
	 * @param sttMode        The mode of STT Operation.
	 * @param targetLanguage target language of the audio data (ex, "ko").
	 * @param encoding       encoding method of the audio data (ex, "raw", "wav", "mp3", "vor", "aac", "fla").
	 * @param channel        channel type of the audio data (ex, Mono: 1, Stereo: 2).
	 * @param sampleRate     sampling rate type of the audio data (ex, 16000, 44100, 48000).
	 * @param sampleFmt      sampling format type of the audio data (ex, "S16LE": signed 16bit little endian, "F32LE": float 32bit little endian).
	 *
	 * @return a JSONObject with the STT result data.
	 */
	public JSONObject requestGenieMemo(final byte[] audioData, String callkey, String lastYn, int callIndex, String selectASYNC) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("lastYn", lastYn);
				metadataJsonObject.put("callIndex", callIndex);
				metadataJsonObject.put("callkey", callkey);

				String strUrl;
				if (selectASYNC.equalsIgnoreCase("GenieMemo")) {
					strUrl = mServiceURL + URL_GENIEMEMO;
					metadataJsonObject.put("lastYn", lastYn);
					metadataJsonObject.put("callIndex", callIndex);
					metadataJsonObject.put("callkey", callkey);
				} else {
					strUrl = mServiceURL + URL_GENIEMEMOASYNC;
					metadataJsonObject.put("callkey", callkey);
				}

				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}
				
				return (JSONObject) HttpUtils.requestMutipart(strUrl, jsonObject, metaData, audioData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_RESULT, e.toString());
				} catch (JSONException e1) {

				}
				return resultJson;
			}
		}
	}

	/**
	 * Query if there is any converted Text.
	 *
	 * @param transactionId transaction id that received sendAudioData result.
	 *
	 * @return a JSONObject with the STT result data.
	 */
	public JSONObject queryGenieMemo(final String callkey) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("callkey", callkey);
				metadataJsonObject.put("callIndex", 0);

				String strUrl = mServiceURL + URL_GENIEMEMOQUERY;
				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestPost(strUrl, jsonObject, metaData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, "여기?!2");// HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {

				}
				return resultJson;
			}
		}
	}
}
