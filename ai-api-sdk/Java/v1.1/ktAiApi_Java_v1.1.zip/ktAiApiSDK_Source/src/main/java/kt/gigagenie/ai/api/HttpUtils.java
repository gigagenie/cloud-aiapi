package kt.gigagenie.ai.api;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.security.SecureRandom;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.Locale;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * HTTP 전송을 위한 HTTP 동작 클래스
 * @author KT AI연구소
 * @since 2021. 02. 01
 * @see
 * <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2021.02.01   KT AI연구소      최초생성
 *   2022.09.27   KT AI연구소      수정사항 적용
 * </pre>
 */
public class HttpUtils
{
    public static final String RESPONSE_STATUS_CODE =  "statusCode";
    public static final String RESPONSE_ERROR_CODE =  "errorCode";
    public static final String RESPONSE_RESULT =  "result";
    public static final String RESPONSE_AUDIO_DATA =  "audioData";

    public static final int RESULT_STATUS_CODE_200 =  200;
    public static final int RESULT_STATUS_CODE_400 =  400;
    public static final int RESULT_STATUS_CODE_401 =  401;
    public static final int RESULT_STATUS_CODE_500 =  500;

    public static final String RESULT_ERROR_CODE_400 =  "파라미터 설정 오류";
    public static final String RESULT_ERROR_CODE_401 =  "권한 없음";
    public static final String RESULT_ERROR_CODE_500 =  "시스템 에러";

    public static final String REQUEST_PARAMETER_AUTHORIZATION = "Authorization";
    public static final String REQUEST_PARAMETER_X_CLIENT_KEY = "x-client-key";
    public static final String REQUEST_PARAMETER_X_AUTH_TIMESTAMP = "x-auth-timestamp";
    public static final String REQUEST_PARAMETER_X_CLIENT_SIGNATURE = "x-client-signature";

    private static final String REQUEST_PARAMETER_CONTENT_TYPE = "Content-type";
    private static final String REQUEST_PARAMETER_CONTENT_LENGTH = "Content-length";

    private static final String LINE_FEED = "\r\n";
    private static final String MULTIPART_BOUNDARY = "9912ef1112228sf8899123f21e8e";
    private static final String CHAR_SET = "utf-8";

    private static final String DEFAULT_ENTRYPOINT = "aiapi.gigagenie.ai";
    private static final int DEFAULT_HTTP_PORT = 55175;
    private static final int DEFAULT_GRPC_PORT = 55174;

    private static final int DEFAULT_HTTP_CONNECT_TIMEOUT = 30 * 1000;
    private static final int DEFAULT_HTTP_SO_TIMEOUT = 60 * 1000;

    /** SSLSocketFactory */
    private static SSLSocketFactory mSSLSocketFactory = null;

    /** HostnameVerifier */
    private static HostnameVerifier mHostnameVerifier = null;

    /** EntryPoint Profile Path */
    private static String mEntryProfilePath = System.getProperty("user.dir") + "\\" + "entryPoint.dat";

    /**
     * Request HTTP get.
     *
     * @param strUrl the url information of http.
     * @param headerJson the JSONObject with the custom header information.
     *
     * @return the object with http response.
     */
    public static Object requestGet(String strUrl, JSONObject headerJson,String body) throws IOException {
        Object object = null;
        final URL mUrl = new URL(strUrl);
        HttpURLConnection conn;
        if (strUrl.contains("https")) {
            try {
                if(mHostnameVerifier == null) {
                    mHostnameVerifier = createHostnameVerifier();
                    HttpsURLConnection.setDefaultHostnameVerifier(mHostnameVerifier);
                }
                if(mSSLSocketFactory == null) {
                    mSSLSocketFactory = createSslSocketFactory();
                    HttpsURLConnection.setDefaultSSLSocketFactory(mSSLSocketFactory);
                }
            } catch (Exception e) {
                throw new IOException("SSL Error: " + e.getMessage());
            }

            conn = (HttpsURLConnection) mUrl.openConnection();
        } else {
            conn = (HttpURLConnection) mUrl.openConnection();
        }

        conn.setRequestMethod("GET");
        conn.setUseCaches(false);
        conn.setConnectTimeout(DEFAULT_HTTP_CONNECT_TIMEOUT);
        conn.setReadTimeout(DEFAULT_HTTP_SO_TIMEOUT);
        conn.setRequestProperty(REQUEST_PARAMETER_CONTENT_LENGTH, "0");

        try {
            Iterator<String> iterator = headerJson.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                String value = headerJson.get(key).toString();

                if (key.contains(REQUEST_PARAMETER_AUTHORIZATION)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_AUTHORIZATION, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_KEY)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_KEY, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_AUTH_TIMESTAMP)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_AUTH_TIMESTAMP, value); // timestamp값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_SIGNATURE)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_SIGNATURE, value); // signature값 설정
                }
                
                if (key.contains("x-server-key")) {
                    conn.addRequestProperty("x-server-key", value); // api-key값 설정
                }
                if (key.contains("x-auth-timestamp")) {
                    conn.addRequestProperty("x-auth-timestamp", value); // timestamp값 설정
                }
                if (key.contains("x-server-signature")) {
                    conn.addRequestProperty("x-server-signature", value); // signature값 설정
                }
            }
        } catch (JSONException e) {
            throw new IOException("JSON Error: " + e.getMessage());
        }

        // checks server's status code first
        int status = conn.getResponseCode();

        if (status == HttpURLConnection.HTTP_OK) {
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            r.close();

            try {
                JSONObject responseJSON = new JSONObject(sb.toString());
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                object = responseJSON;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            conn.disconnect();
        } else if(status == HttpURLConnection.HTTP_MOVED_PERM) {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                JSONObject responseJSON = new JSONObject(builder.toString());

                String strEntryPoint = "";
                if(!responseJSON.isNull("entrypoint")){
                    strEntryPoint = responseJSON.getString("entrypoint");
                }

                if(!isEmpty(strEntryPoint)){
                    setHttpEntrypoint(strEntryPoint);
                    String strurl = getHttpEntrypointUrl() + mUrl.getPath();
                    object = requestGet(strurl, headerJson, "");

                }else{
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                    object = responseJSON;
                }

                return object;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
        } else {
            JSONObject responseJSON = new JSONObject();
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, conn.getResponseCode());
                responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, builder.toString());
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            object = responseJSON;
        }

        return object;
    }

    public static Object requestDelete(String strUrl, JSONObject headerJson,String body) throws IOException {
        Object object = null;
        final URL mUrl = new URL(strUrl);
        HttpURLConnection conn;
        if (strUrl.contains("https")) {
            try {
                if(mHostnameVerifier == null) {
                    mHostnameVerifier = createHostnameVerifier();
                    HttpsURLConnection.setDefaultHostnameVerifier(mHostnameVerifier);
                }
                if(mSSLSocketFactory == null) {
                    mSSLSocketFactory = createSslSocketFactory();
                    HttpsURLConnection.setDefaultSSLSocketFactory(mSSLSocketFactory);
                }
            } catch (Exception e) {
                throw new IOException("SSL Error: " + e.getMessage());
            }

            conn = (HttpsURLConnection) mUrl.openConnection();
        } else {
            conn = (HttpURLConnection) mUrl.openConnection();
        }

        conn.setRequestMethod("DELETE");
        conn.setUseCaches(false);
        conn.setConnectTimeout(DEFAULT_HTTP_CONNECT_TIMEOUT);
        conn.setReadTimeout(DEFAULT_HTTP_SO_TIMEOUT);
        conn.setRequestProperty(REQUEST_PARAMETER_CONTENT_LENGTH, "0");

        try {
            Iterator<String> iterator = headerJson.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                String value = headerJson.get(key).toString();
                
                if (key.contains("x-server-key")) {
                    conn.addRequestProperty("x-server-key", value); // api-key값 설정
                }
                if (key.contains("x-auth-timestamp")) {
                    conn.addRequestProperty("x-auth-timestamp", value); // timestamp값 설정
                }
                if (key.contains("x-server-signature")) {
                    conn.addRequestProperty("x-server-signature", value); // signature값 설정
                }
            }
        } catch (JSONException e) {
            throw new IOException("JSON Error: " + e.getMessage());
        }

        // checks server's status code first
        int status = conn.getResponseCode();

        if (status == HttpURLConnection.HTTP_OK) {
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            r.close();

            try {
                JSONObject responseJSON = new JSONObject();
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                responseJSON.put(HttpUtils.RESPONSE_RESULT, "완료!");
                object = responseJSON;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            conn.disconnect();
        } else if(status == HttpURLConnection.HTTP_MOVED_PERM) {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                JSONObject responseJSON = new JSONObject(builder.toString());

                String strEntryPoint = "";
                if(!responseJSON.isNull("entrypoint")){
                    strEntryPoint = responseJSON.getString("entrypoint");
                }

                if(!isEmpty(strEntryPoint)){
                    setHttpEntrypoint(strEntryPoint);
                    String strurl = getHttpEntrypointUrl() + mUrl.getPath();
                    object = requestGet(strurl, headerJson, "");

                }else{
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                    object = responseJSON;
                }

                return object;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
        } else {
            JSONObject responseJSON = new JSONObject();
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, conn.getResponseCode());
                responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, builder.toString());
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            object = responseJSON;
        }

        return object;
    }
    
    
    //Request Http put
    public static Object requestPut(String strUrl, JSONObject headerJson,String body) throws IOException {
    	Object object = null;
        final URL mUrl = new URL(strUrl);
        HttpURLConnection conn;
        if (strUrl.contains("https")) {
            try {
                if(mHostnameVerifier == null) {
                    mHostnameVerifier = createHostnameVerifier();
                    HttpsURLConnection.setDefaultHostnameVerifier(mHostnameVerifier);
                }
                if(mSSLSocketFactory == null) {
                    mSSLSocketFactory = createSslSocketFactory();
                    HttpsURLConnection.setDefaultSSLSocketFactory(mSSLSocketFactory);
                }
            } catch (Exception e) {
                throw new IOException("SSL Error: " + e.getMessage());
            }

            conn = (HttpsURLConnection) mUrl.openConnection();
        } else {
            conn = (HttpURLConnection) mUrl.openConnection();
        }

        conn.setRequestMethod("PUT");
        conn.setUseCaches(false);
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setConnectTimeout(DEFAULT_HTTP_CONNECT_TIMEOUT);
        conn.setReadTimeout(DEFAULT_HTTP_SO_TIMEOUT);
        
        conn.setRequestProperty(REQUEST_PARAMETER_CONTENT_TYPE, "application/json");
        try {
            Iterator<String> iterator = headerJson.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                String value = headerJson.get(key).toString();
                
                if (key.contains("x-server-key")) {
                    conn.addRequestProperty("x-server-key", value); // api-key값 설정
                }
                if (key.contains("x-auth-timestamp")) {
                    conn.addRequestProperty("x-auth-timestamp", value); // timestamp값 설정
                }
                if (key.contains("x-server-signature")) {
                    conn.addRequestProperty("x-server-signature", value); // signature값 설정
                }
            }
        } catch (JSONException e) {
            throw new IOException("JSON Error: " + e.getMessage());
        }
        
        try {
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(body); //json 형식의 message 전달
            wr.flush();
        } catch (Exception e){
            throw new IOException("jsonMessage write error: " + e.getMessage());
        }
        
        // checks server's status code first
        int status = conn.getResponseCode();
        if (status == HttpURLConnection.HTTP_OK) {
        	StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            r.close();
            try {
            	JSONObject responseJSON = new JSONObject();
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                responseJSON.put(HttpUtils.RESPONSE_RESULT, "완료!");
                object = responseJSON;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            conn.disconnect();
        } else if(status == HttpURLConnection.HTTP_MOVED_PERM) {
        	StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                JSONObject responseJSON = new JSONObject(builder.toString());

                String strEntryPoint = "";
                if(!responseJSON.isNull("entrypoint")){
                    strEntryPoint = responseJSON.getString("entrypoint");
                }

                if(!isEmpty(strEntryPoint)){
                    setHttpEntrypoint(strEntryPoint);
                    String strurl = getHttpEntrypointUrl() + mUrl.getPath();
                    object = requestGet(strurl, headerJson, "");

                }else{
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                    object = responseJSON;
                }

                return object;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
        } else {
            JSONObject responseJSON = new JSONObject();
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, conn.getResponseCode());
                responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, builder.toString());
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            object = responseJSON;
        }
        return object;
    }
    

    /**
     * Request HTTP post with meta data.
     *
     * @param strUrl the url information of http.
     * @param headerJson the JSONObject with the custom header information.
     * @param jsonMessage the value of media meta information.
     *
     * @return the object with http response.
     */
    public static Object requestPost(String strUrl, JSONObject headerJson, String jsonMessage) throws IOException{
        Object object = null;
        final URL mUrl = new URL(strUrl);
        HttpURLConnection conn;
        if (strUrl.contains("https")) {
            try {
                if(mHostnameVerifier == null) {
                    mHostnameVerifier = createHostnameVerifier();
                    HttpsURLConnection.setDefaultHostnameVerifier(mHostnameVerifier);
                }
                if(mSSLSocketFactory == null) {
                    mSSLSocketFactory = createSslSocketFactory();
                    HttpsURLConnection.setDefaultSSLSocketFactory(mSSLSocketFactory);
                }
            } catch (Exception e) {
                throw new IOException("SSL Error: " + e.getMessage());
            }

            conn = (HttpsURLConnection) mUrl.openConnection();
        } else {
            conn = (HttpURLConnection) mUrl.openConnection();
        }

        conn.setRequestMethod("POST");
        conn.setUseCaches(false);
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setConnectTimeout(DEFAULT_HTTP_CONNECT_TIMEOUT);
        conn.setReadTimeout(DEFAULT_HTTP_SO_TIMEOUT);

        conn.setRequestProperty(REQUEST_PARAMETER_CONTENT_TYPE, "application/json");
        try {
            Iterator<String> iterator = headerJson.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                String value = headerJson.get(key).toString();

                if (key.contains(REQUEST_PARAMETER_AUTHORIZATION)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_AUTHORIZATION, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_KEY)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_KEY, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_AUTH_TIMESTAMP)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_AUTH_TIMESTAMP, value); // timestamp값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_SIGNATURE)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_SIGNATURE, value); // signature값 설정
                }
                if (key.contains("x-server-key")) {
                    conn.addRequestProperty("x-server-key", value); // api-key값 설정
                }
                if (key.contains("x-auth-timestamp")) {
                    conn.addRequestProperty("x-auth-timestamp", value); // timestamp값 설정
                }
                if (key.contains("x-server-signature")) {
                    conn.addRequestProperty("x-server-signature", value); // signature값 설정
                }
            }
        } catch (JSONException e) {
        	throw new IOException("error: " + e.getMessage());
        }
        
        try {
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(jsonMessage); //json 형식의 message 전달
            wr.flush();
        } catch (Exception e){
            throw new IOException("jsonMessage write error: " + e.getMessage());
        }
        // checks server's status code first
        int status = conn.getResponseCode();
        JSONObject responseJSON = new JSONObject();
        if (status == HttpURLConnection.HTTP_OK) {
            if (conn.getContentType().contains("octet-stream")) {
            	int size = conn.getContentLength();
                byte[] buffer = new byte[size];
                DataInputStream dis = new DataInputStream(conn.getInputStream());
                dis.readFully(buffer);
                try {
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                    responseJSON.put(HttpUtils.RESPONSE_AUDIO_DATA, buffer);
                }catch (JSONException e1){
                    throw new IOException("JSON Error: " + e1.getMessage());
                }	
            } else if (conn.getContentType().contains("json") || conn.getContentType().contains("text") ){
            	BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                String strCurrentLine;
                StringBuilder sb = new StringBuilder();
                    while ((strCurrentLine = br.readLine()) != null) {
                    	sb.append(strCurrentLine);
                    }
                    
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                responseJSON.put(HttpUtils.RESPONSE_RESULT, sb );
                conn.disconnect();
                object = responseJSON;
            } else {
                try {
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, "여기?");//HttpUtils.RESULT_ERROR_CODE_500);
                }catch (JSONException e1){
                    throw new IOException("JSON Error: " + e1.getMessage());
                }
            }
            object = responseJSON;
            conn.disconnect();
        } else if(status == HttpURLConnection.HTTP_MOVED_PERM) {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                JSONObject responseJSONData = new JSONObject(builder.toString());

                String strEntryPoint = "";
                if(!responseJSONData.isNull("entrypoint")){
                    strEntryPoint = responseJSONData.getString("entrypoint");
                }

                if(!isEmpty(strEntryPoint)){
                    setHttpEntrypoint(strEntryPoint);
                    String strurl = getHttpEntrypointUrl() + mUrl.getPath();
                    object = requestPost(strurl, headerJson, jsonMessage);
                }else{
                    responseJSONData.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSONData.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                    object = responseJSONData;
                }

                return object;
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }

        } else {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line);
            }
            in.close();
            try {
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, conn.getResponseCode());
                responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, builder.toString());
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
            object = responseJSON;
        }
        
        return object;
    }

    /**
     * Request HTTP multipart post with data.
     *
     * @param strUrl the url information of http.
     * @param headerJson the JSONObject with the custom header information.
     * @param mediaMetaData the value of media meta information.
     * @param mediaData a byte array with the media data.
     *
     * @return the object with http response.
     */
    public static Object requestMutipart(String strUrl, JSONObject headerJson, String mediaMetaData, byte[] mediaData) throws IOException {
        final URL mUrl = new URL(strUrl);
        HttpURLConnection conn;
        if (strUrl.contains("https")) {
            try {
                if(mHostnameVerifier == null) {
                    mHostnameVerifier = createHostnameVerifier();
                    HttpsURLConnection.setDefaultHostnameVerifier(mHostnameVerifier);
                }
                if(mSSLSocketFactory == null) {
                    mSSLSocketFactory = createSslSocketFactory();
                    HttpsURLConnection.setDefaultSSLSocketFactory(mSSLSocketFactory);
                }
            } catch (Exception e) {
                throw new IOException("SSL Error: " + e.getMessage());
            }

            conn = (HttpsURLConnection) mUrl.openConnection();
        } else {
            conn = (HttpURLConnection) mUrl.openConnection();
        }

        conn.setRequestMethod("POST");
        conn.setUseCaches(false);
        conn.setDoInput(true);
        conn.setDoOutput(true);
        conn.setConnectTimeout(DEFAULT_HTTP_CONNECT_TIMEOUT);
        conn.setReadTimeout(DEFAULT_HTTP_SO_TIMEOUT);

        conn.setRequestProperty(REQUEST_PARAMETER_CONTENT_TYPE, "multipart/form-data; boundary=" + MULTIPART_BOUNDARY);
        try {
            Iterator<String> iterator = headerJson.keys();
            while (iterator.hasNext()) {
                String key = iterator.next();
                String value = headerJson.get(key).toString();

                if (key.contains(REQUEST_PARAMETER_AUTHORIZATION)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_AUTHORIZATION, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_KEY)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_KEY, value); // api-key값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_AUTH_TIMESTAMP)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_AUTH_TIMESTAMP, value); // timestamp값 설정
                }
                if (key.contains(REQUEST_PARAMETER_X_CLIENT_SIGNATURE)) {
                    conn.addRequestProperty(REQUEST_PARAMETER_X_CLIENT_SIGNATURE, value); // signature값 설정
                }
            }
        } catch (JSONException e) {
            throw new IOException("JSON Error: " + e.getMessage());
        }
        try {
            OutputStream outputStream = conn.getOutputStream();
            PrintWriter writer = new PrintWriter(new OutputStreamWriter(outputStream, CHAR_SET), true);

            // send media meta data
            writer.append("--" + MULTIPART_BOUNDARY).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"metadata\"").append(LINE_FEED);
            writer.append("Content-Type: application/json; charset=" + CHAR_SET).append(LINE_FEED);
            writer.append(LINE_FEED);
            writer.append(mediaMetaData).append(LINE_FEED);
            writer.flush();
            
            // send media data
            writer.append("--" + MULTIPART_BOUNDARY).append(LINE_FEED);
            writer.append("Content-Disposition: form-data; name=\"media\"").append(LINE_FEED);
            writer.append("Content-Type: application/octet-stream").append(LINE_FEED);
            writer.append("Content-Transfer-Encoding: binary").append(LINE_FEED);
            writer.append(LINE_FEED);
            writer.flush();
            
            InputStream inputStream = new ByteArrayInputStream(mediaData);
            byte[] buffer = new byte[4096];
            int bytesRead = -1;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }
            inputStream.close();
            outputStream.flush();
            writer.append(LINE_FEED);
            writer.flush();

            writer.append("--" + MULTIPART_BOUNDARY + "--").append(LINE_FEED);
            writer.flush();
            writer.close();
            
        } catch (Exception e){
            throw new IOException("media-data write error: " + e.getMessage());
        }
        // checks server's status code first
        int status = conn.getResponseCode();
        JSONObject responseJSON = new JSONObject();
        if (status == HttpURLConnection.HTTP_OK) {
        	if(conn.getContentType().contains("octet-stream")){
            	int size = conn.getContentLength();
            	byte[] buffer = new byte[size];
                DataInputStream dis = new DataInputStream(conn.getInputStream());
                dis.readFully(buffer);
                try {
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                    responseJSON.put(HttpUtils.RESPONSE_AUDIO_DATA, buffer);
                }catch (JSONException e1){
                    throw new IOException("JSON Error: " + e1.getMessage());
                }
                conn.disconnect();
                return responseJSON;
        	}
            StringBuilder sb = new StringBuilder();
            BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = r.readLine()) != null) {
                sb.append(line).append("\r\n");
            }
            r.close();
            conn.disconnect();

            if(conn.getContentType().contains("multipart")){
                String boundary = getBoundary(conn.getContentType());
                String content = sb.toString();

                ArrayList<String> stream = getMultipartStream(content, boundary);
                try {
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_200);
                    JSONArray jsonArray = new JSONArray();
                    for (int j = 0; j < stream.size(); j++) {
                        try {
                            String strResult = readBodyData(stream.get(j));

                            JSONObject resultObject = new JSONObject(strResult);
                            jsonArray.put(j, resultObject);
                        }catch(Exception e){
                            throw new IOException("response data : " + e.getMessage());
                        }
                    }
                    responseJSON.put(HttpUtils.RESPONSE_RESULT, jsonArray);
                }catch (JSONException e1){
                    throw new IOException("JSON Error: " + e1.getMessage());
                }
                return responseJSON;
            }else{
                try {
                    responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                }catch (JSONException e1){
                    throw new IOException("JSON Error: " + e1.getMessage());
                }
            }
        } else if(status == HttpURLConnection.HTTP_MOVED_PERM) {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\n");
            }
            in.close();
            try {
                Object object = null;

                JSONObject responseJSONData = new JSONObject(builder.toString());

                String strEntryPoint = "";
                if(!responseJSONData.isNull("entrypoint")){
                    strEntryPoint = responseJSONData.getString("entrypoint");
                }

                if(!isEmpty(strEntryPoint)){
                    setHttpEntrypoint(strEntryPoint);
                    String strurl = getHttpEntrypointUrl() + mUrl.getPath();
                    object = requestMutipart(strurl, headerJson, mediaMetaData, mediaData);

                }else{
                    responseJSONData.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
                    responseJSONData.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
                    object = responseJSONData;
                }
                return object;

            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }

        } else {
            StringBuilder builder = new StringBuilder();
            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = in.readLine()) != null) {
                builder.append(line).append("\r\n");
            }
            in.close();
            try {
                responseJSON.put(HttpUtils.RESPONSE_STATUS_CODE, conn.getResponseCode());
                responseJSON.put(HttpUtils.RESPONSE_ERROR_CODE, builder.toString());
            }catch (JSONException e1){
                throw new IOException("JSON Error: " + e1.getMessage());
            }
        }
        return responseJSON;
    }


    /**
     * Retrieves the multipart form-data's from the response multipart data.
     *
     * @param content the value of the response multipart data.
     * @param boundary the value of the multipart boundary.
     *
     * @return array list with the multipart form-data.
     */
    private static ArrayList<String> getMultipartStream(String content, String boundary) {
        String[] strBody = content.split("--" + boundary);
        ArrayList<String> strList = new ArrayList<>();
        for (int i = 0; i < strBody.length; i++) {
            String text = strBody[i];
            if (text.contains("form-data")) {
                strList.add(text);
            }
        }
        return strList;
    }

    /**
     * Retrieves the body data from the multipart form-data.
     *
     * @param multipart the value of the multipart form-data.
     *
     * @return the body data of the multipart data.
     */
    private static String readBodyData(String multipart) {
        String[] strBody = multipart.split(LINE_FEED);
        StringBuilder result = new StringBuilder();
        int insertindex = 0;
        for (int i = 0; i < strBody.length; i++) {
            String text = strBody[i];
            if (text.contains("Content-") || isEmpty(text)) {
                continue;
            }
            if(insertindex > 0) result.append(LINE_FEED);
            result.append(text);
            insertindex++;
        }
        return result.toString();
    }

    /**
     * Retrieves the boundary that is used to separate the request parts from the Content-Type header.
     *
     * @param contentType the value of the Content-Type header.
     *
     * @return a byte array with the boundary.
     */
    private static String getBoundary(String contentType) {
        String strBoundary = contentType.split("boundary=")[1].trim();
        return strBoundary;
    }

    /**
     * Gets Current Timestamp
     *
     * @return Timestamp
     */
    public static String getTimestamp(){
        SimpleDateFormat simpleDateFormat= new SimpleDateFormat("yyyyMMddHHmmssSSS", Locale.getDefault());
        Date today = new Date();
        String timestamp = simpleDateFormat.format(today);
        return timestamp;
    }

    /**
     * Make Signature
     *
     * @param timestamp the value of timestamp.
     * @param client_id the value of the client id.
     * @param client_secret the value of the client secret.
     *
     * @return Signature
     */
    public static String makeSignature(String timestamp, String client_id, String client_secret){
        String digest = null;
        try {
            SecretKeySpec key = new SecretKeySpec((client_secret).getBytes(StandardCharsets.UTF_8), "HmacsSHA256");
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(key);
            String digestTarget = client_id + ":" + timestamp;
            byte[] bytes = mac.doFinal(digestTarget.getBytes(StandardCharsets.US_ASCII));
            StringBuffer hash = new StringBuffer();
            for(int i = 0; i < bytes.length; i++) {
                String hex = Integer.toHexString(0xFF & bytes[i]);
                if(hex.length() == 1) hash.append('0');
                hash.append(hex);
            }
            digest = hash.toString();
        } catch(Exception e) {

        }
        return digest;
    }

    /**
     * Create Host Name Verifier
     * These callbacks are used when the default rules for URL hostname verification.
     *
     * @return HostnameVerifier
     */
    private static HostnameVerifier createHostnameVerifier() {
        HostnameVerifier hostnameVerifier = new HostnameVerifier(){
            public boolean verify(String hostname, SSLSession session) {
            	if(hostname.equalsIgnoreCase("dev.gigagenie.ai") ||
                        hostname.equalsIgnoreCase("tbaiapigw.gigagenie.ai") ||
                        hostname.equalsIgnoreCase("aiapigw.gigagenie.ai")){
                    return true;
                }else{
                    return false;
                }
            }};
        return hostnameVerifier;
    }

    /**
     * Create SSLSocketFactory
     * Socket factories are a simple way to capture a variety of policies related to the sockets being constructed.
     *
     * @return SSLSocketFactory
     */
    private static SSLSocketFactory createSslSocketFactory() throws GeneralSecurityException, IOException {
        // Create a TrustManager that does not validate certificate chains
        TrustManager[] trustManagers = new TrustManager[] { new X509TrustManager() {
            public X509Certificate[] getAcceptedIssuers() {
                return new X509Certificate[0];
            }

            public void checkClientTrusted(X509Certificate[] chain, String authType) {
            }

            public void checkServerTrusted(X509Certificate[] chain, String authType) {
            }
        } };

        // Create an SSL Socket Factory with our TrustManager
        SSLContext sslContext = SSLContext.getInstance("SSL");
        sslContext.init(null, trustManagers, new SecureRandom());
        return sslContext.getSocketFactory();
    }

    /**
     * Returns true if the string is null or 0-length.
     * @param str the string to be examined
     *
     * @return true if str is null or zero length
     */
    public static boolean isEmpty(CharSequence str) {
        return str == null || str.length() == 0;
    }

    /**
     * check EntryPoint Profile Initialization
     *
     */
    public static void checkEntryPointProfile(){
        try {
            final File file = new File(mEntryProfilePath);
            if (!file.exists()) {
                JSONObject entryPointObject = new JSONObject();
                entryPointObject.put("entryPoint", DEFAULT_ENTRYPOINT);
                entryPointObject.put("httpPort", DEFAULT_HTTP_PORT);
                entryPointObject.put("grpcPort", DEFAULT_GRPC_PORT);

                String entryPoint = entryPointObject.toString();
                FileOutputStream fos = new FileOutputStream(mEntryProfilePath);
                fos.write(entryPoint.getBytes(), 0, entryPoint.length());
                fos.close();
            }

        }catch (Exception e){

        }
    }

    /**
     * update EntryPoint Profile.
     *
     * @param entryPoint the value of entryPoint
     * @param httpPort the value of httpPort
     * @param grpcPort the value of grpcPort
     *
     */
    public static void updateEntryPointProfile(String entryPoint, int httpPort, int grpcPort){
        try {
            JSONObject entryPointObject = new JSONObject();
            entryPointObject.put("entryPoint", entryPoint);
            entryPointObject.put("httpPort", httpPort);
            entryPointObject.put("grpcPort", grpcPort);

            String entryPointStr = entryPointObject.toString();
            FileOutputStream fos = new FileOutputStream(mEntryProfilePath);
            fos.write(entryPointStr.getBytes(), 0, entryPointStr.length());
            fos.close();

        }catch (Exception e){

        }
    }

    /**
     * Gets URL Information of HTTP.
     *
     * @return the URL Information of HTTP.
     */
    public static String getHttpEntrypointUrl(){
        String strUrl = "";
        try {

            byte[] readByte = null;
            FileInputStream inputStream = new FileInputStream(mEntryProfilePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            readByte = bos.toByteArray();

            inputStream.close();
            bos.close();

            String Profile = new String(readByte);

            JSONObject entryPointObject = new JSONObject(Profile);
            String hostname = entryPointObject.getString("entryPoint");
            int port = entryPointObject.getInt("httpPort");

            strUrl = "https://" + hostname + ":" + port;

        }catch (Exception e){

        }

        if(isEmpty(strUrl)){
            strUrl = "https://" + DEFAULT_ENTRYPOINT + ":" + DEFAULT_HTTP_PORT;
        }

        return strUrl;
    }

    /**
     * Gets EntryPoint Information of GRPC.
     *
     * @return the EntryPoint Information of GRPC.
     */
    public static String getGrpcEntrypoint(){
        String strEntryPoint = "";
        try {
            byte[] readByte = null;
            FileInputStream inputStream = new FileInputStream(mEntryProfilePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            readByte = bos.toByteArray();

            inputStream.close();
            bos.close();

            String Profile = new String(readByte);

            JSONObject entryPointObject = new JSONObject(Profile);
            strEntryPoint = entryPointObject.getString("entryPoint");

        }catch (Exception e){

        }

        if(isEmpty(strEntryPoint)){
            strEntryPoint = DEFAULT_ENTRYPOINT;
        }

        return strEntryPoint;
    }

    /**
     * Gets Port Information of GRPC.
     *
     * @return the Port Information of GRPC.
     */
    public static int getGrpcPort(){
        int grpcPort = DEFAULT_GRPC_PORT;

        try {
            byte[] readByte = null;
            FileInputStream inputStream = new FileInputStream(mEntryProfilePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            readByte = bos.toByteArray();

            inputStream.close();
            bos.close();

            String Profile = new String(readByte);

            JSONObject entryPointObject = new JSONObject(Profile);
            grpcPort = entryPointObject.getInt("grpcPort");

        }catch (Exception e){

        }

        return grpcPort;
    }

    /**
     * Sets URL Information of HTTP.
     *
     * @param strUrl the URL Information of HTTP.
     *
     */
    public static void setHttpEntrypoint(String strUrl) {
        try {
            String hostname;
            String host;
            int port;

            if (strUrl.indexOf("//") > -1) {
                host = strUrl.split("/")[2];
            } else {
                host = strUrl.split("/")[0];
            }

            hostname = host.split(":")[0];
            port = Integer.parseInt(host.split(":")[1]);

            byte[] readByte = null;
            FileInputStream inputStream = new FileInputStream(mEntryProfilePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            readByte = bos.toByteArray();

            inputStream.close();
            bos.close();

            String Profile = new String(readByte);

            JSONObject entryPointObject = new JSONObject(Profile);
            entryPointObject.put("entryPoint", hostname);
            entryPointObject.put("httpPort", port);

            String entryPoint = entryPointObject.toString();
            FileOutputStream fos = new FileOutputStream(mEntryProfilePath);
            fos.write(entryPoint.getBytes(), 0, entryPoint.length());
            fos.close();

        } catch (Exception e) {

        }
    }

    /**
     * Sets URL Information of GRPC.
     *
     * @param strUrl the URL Information of GRPC.
     *
     */
    public static void setGrpcEntrypoint(String strUrl){
        try {
            String hostname;
            String host;
            int port;

            if (strUrl.indexOf("//") > -1) {
                host = strUrl.split("/")[2];
            } else {
                host = strUrl.split("/")[0];
            }

            hostname = host.split(":")[0];
            port = Integer.parseInt(host.split(":")[1]);

            byte[] readByte = null;
            FileInputStream inputStream = new FileInputStream(mEntryProfilePath);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead = 0;
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }

            readByte = bos.toByteArray();

            inputStream.close();
            bos.close();

            String Profile = new String(readByte);

            JSONObject entryPointObject = new JSONObject(Profile);
            entryPointObject.put("entryPoint", hostname);
            entryPointObject.put("grpcPort", port);

            String entryPoint = entryPointObject.toString();
            FileOutputStream fos = new FileOutputStream(mEntryProfilePath);
            fos.write(entryPoint.getBytes(), 0, entryPoint.length());
            fos.close();
        } catch (Exception e) {

        }
    }
}
