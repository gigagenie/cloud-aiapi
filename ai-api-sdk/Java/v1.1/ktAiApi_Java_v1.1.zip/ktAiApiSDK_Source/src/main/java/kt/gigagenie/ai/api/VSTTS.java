package kt.gigagenie.ai.api;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * HTTP를 이용한 합성 보이스 처리 AI SDK API 제공 클래스
 * 
 * @author KT AI연구소
 * @since 2022. 09. 27
 * @see
 * 
 *      <pre>
 * << 개정이력 개정이력 (Modification Information) >>
 *   수정일         수정자           수정내용
 *  -----------  ------------  ---------------------------
 *   2022.09.27   KT AI연구소      최초생성
 *      </pre>
 */
public class VSTTS {

	/** VSTTS Synthesis URL */
	private final String URL_VSTTS_VOICE_SYNTHESIS = "/v2/voicestudio/voiceSynthesis";

	/** service url */
	private String mServiceURL;

	/** clientKey */
	private String mClientKey;

	/** timestamp */
	private String mTimeStamp;

	/** signature */
	private String mSignature;

	/**
	 * Creates a new TTS.
	 */
	public VSTTS() {
		HttpUtils.checkEntryPointProfile();
	}

	/**
	 * Sets Auth Information of TTS.
	 *
	 * @param clientKey    the value of the API Key.
	 * @param clientId     the value of the client id.
	 * @param clientSecret the value of the client secret.
	 *
	 */
	public void setAuth(String clientKey, String clientId, String clientSecret) {
		if (HttpUtils.isEmpty(clientKey)) {
			return;
		}

		this.mClientKey = clientKey;

		if (!HttpUtils.isEmpty(clientId) && !HttpUtils.isEmpty(clientSecret)) {
			this.mTimeStamp = HttpUtils.getTimestamp();
			this.mSignature = HttpUtils.makeSignature(mTimeStamp, clientId, clientSecret);
		}
	}

	/**
	 * Sets URL Information of service.
	 *
	 * @param endpoint the URL Information of service.
	 *
	 */
	public void setServiceURL(String endpoint) {
		HttpUtils.setHttpEntrypoint(endpoint);
	}

	/**
	 * Sends a text data for convert to Speech.
	 *
	 * @param text       the data of text for convert to speech.
	 * @param pitch      the value of pitch.
	 * @param speed      the value of speed.
	 * @param speaker    the mode of speaker.
	 * @param volume     the level of volume.
	 * @param language   language of the audio data (ex, "ko").
	 * @param encoding   encoding method of the audio data (ex, "wav", "mp3").
	 * @param channel    channel type of the audio data in case "wav" encoding (ex, Mono: 1, Stereo: 2).
	 * @param sampleRate sampling rate type of the audio data in case "wav" encoding (ex, 24000, 16000, 8000).
	 * @param sampleFmt  sampling format type of the audio data in case "wav" encoding (ex, "S16LE": signed 16bit little endian, "F32LE": float 32bit little endian).*
	 *
	 * @return a JSONObject with the TTS result data.
	 */
	public JSONObject requestVSTTS(final String text, int pitch, int speed, int speaker, int volume, String language, String encoding, int channel, int sampleRate, String sampleFmt, String emotion,
			String voiceName) {
		synchronized (this) {
			JSONObject resultJson = new JSONObject();

			try {
				mServiceURL = HttpUtils.getHttpEntrypointUrl();

				JSONObject metadataJsonObject = new JSONObject();
				metadataJsonObject.put("text", text);
				metadataJsonObject.put("speaker", speaker);
				metadataJsonObject.put("voiceName", voiceName);
				metadataJsonObject.put("pitch", pitch);
				metadataJsonObject.put("speed", speed);
				metadataJsonObject.put("volume", volume);
				metadataJsonObject.put("language", language);
				metadataJsonObject.put("encoding", encoding);
				metadataJsonObject.put("emotion", emotion);

				if (encoding.equalsIgnoreCase("wav")) {
					JSONObject encodingOptObject = new JSONObject();
					encodingOptObject.put("channel", channel);
					encodingOptObject.put("sampleRate", sampleRate);
					encodingOptObject.put("sampleFmt", sampleFmt);

					metadataJsonObject.put("encodingOpt", encodingOptObject);
				}

				String strUrl = mServiceURL + URL_VSTTS_VOICE_SYNTHESIS;
				String metaData = metadataJsonObject.toString();

				JSONObject jsonObject = new JSONObject();
				if (!HttpUtils.isEmpty(mTimeStamp) && !HttpUtils.isEmpty(mSignature)) {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_KEY, mClientKey);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_AUTH_TIMESTAMP, mTimeStamp);
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_X_CLIENT_SIGNATURE, mSignature);
				} else {
					jsonObject.put(HttpUtils.REQUEST_PARAMETER_AUTHORIZATION, mClientKey);
				}

				return (JSONObject) HttpUtils.requestPost(strUrl, jsonObject, metaData);
			} catch (Exception e) {
				try {
					resultJson.put(HttpUtils.RESPONSE_STATUS_CODE, HttpUtils.RESULT_STATUS_CODE_500);
					resultJson.put(HttpUtils.RESPONSE_ERROR_CODE, HttpUtils.RESULT_ERROR_CODE_500);
				} catch (JSONException e1) {

				}
				return resultJson;
			}
		}
	}
}
