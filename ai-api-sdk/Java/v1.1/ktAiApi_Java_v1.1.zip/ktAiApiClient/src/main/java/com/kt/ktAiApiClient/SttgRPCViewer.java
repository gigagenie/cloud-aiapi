package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileInputStream;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingUtilities;

import kt.gigagenie.ai.api.STTgRPC;
import kt.gigagenie.ai.api.STTgRPCCallback;

public class SttgRPCViewer extends JFrame {
	private JPanel panelMain;
	private JLabel mainLabel;
	private JLabel statusLabel;
	private JButton connectButton;
	private JButton disconnectButton;
	private JButton sendFileButton;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;

	private JLabel fileSelectLbl;
	private JFileChooser fileChooser;
	private File targetFile = null;

	private JComboBox modeList;
	private JComboBox channelList;
	private JComboBox sampleRateList;
	private JComboBox sampleFmtList;
	private JComboBox sttModelCodeList;

	private STTgRPC mSttgRPC = null;

	private int mSampleRate = 16000;

	private boolean isSending = false;

	private String mExistText = "";

	private STTgRPCCallback onSTTgRPCCallbackListener = new STTgRPCCallback() {
		@Override
		public void onConnectGRPC() {

			statusLabel.setText("Connected");
			connectButton.setEnabled(false);
			disconnectButton.setEnabled(true);
			sendFileButton.setEnabled(true);
		}

		@Override
		public void onSTTResult(String text, String type, float startTime, float endTime) {

			StringBuilder sb = new StringBuilder();
			sb.append(text);
			if (type.equalsIgnoreCase("full")) {
				sb.append("\n");
				taskOutput.setText(mExistText);
				taskOutput.append(sb.toString());
				mExistText = taskOutput.getText();
			} else {
				taskOutput.setText(mExistText);
				taskOutput.append(sb.toString());
			}
		}

		@Override
		public void onReadySTT(int sampleRate, int channel, String format) {
			mSampleRate = sampleRate;
			statusLabel.setText("** File Sending **");
			SendAudioFile();
		}

		@Override
		public void onStopSTT() {
			isSending = false;
			statusLabel.setText("Connected");
			disconnectButton.setEnabled(true);
			sendFileButton.setEnabled(true);
		}

		@Override
		public void onRelease() {
			statusLabel.setText("Disconnected");
			connectButton.setEnabled(true);
			disconnectButton.setEnabled(false);
			sendFileButton.setEnabled(false);
		}

		@Override
		public void onError(int errCode, String errMsg) {
			isSending = false;
			mSttgRPC.releaseConnection();
			JOptionPane.showMessageDialog(panelMain, "STT로 변환요청 중 에러가 발생하였습니다. \r\n" + "errCode:" + errCode + ", errMsg:" + errMsg, "Warning", JOptionPane.WARNING_MESSAGE);
		}
	};

	public SttgRPCViewer() {
		super("STT gRPC API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(1024, 768));
		setSize(1024, 768);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mSttgRPC != null) {
					mSttgRPC.releaseConnection();
					mSttgRPC = null;
				}
				System.exit(0);
			}
		});
		pack();
		setVisible(true);

		if (mSttgRPC == null) {
			mSttgRPC = new STTgRPC();
			mSttgRPC.setSTTgRPCCallback(onSTTgRPCCallbackListener);
			mSttgRPC.setServiceURL(ENV.hostname + ":" + ENV.ai_api_grpc_port);
			mSttgRPC.setMetaData(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		SttgRPCViewer viewer = new SttgRPCViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		fileChooser = new JFileChooser();

		mainLabel = new JLabel("STT gRPC API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		statusLabel = new JLabel("Disconnected");
		statusLabel.setSize(40, 40);
		statusLabel.setForeground(Color.RED);
		statusLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(false);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		JPanel upperPanel = new JPanel();
		upperPanel.setLayout(new GridLayout(2, 1));
		upperPanel.add(mainLabel);
		upperPanel.add(statusLabel);

		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(14, 1));

		fileSelectLbl = new JLabel("Select File", JLabel.CENTER);
		fileSelectLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JButton fileButton = new JButton("Open...");
		fileButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int returnVal = fileChooser.showOpenDialog(SttgRPCViewer.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					targetFile = fileChooser.getSelectedFile();
					// This is where a real application would open the file.
					fileSelectLbl.setText("File [" + targetFile.getName() + "]");
				} else {

				}
			}
		});

		controlPanel.add(fileSelectLbl);
		controlPanel.add(fileButton);

		String[] encodingStrings = { "long", "cmd" };

		JLabel modeLbl = new JLabel("MODE", JLabel.CENTER);
		modeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		modeList = new JComboBox(encodingStrings);
		modeList.setSelectedIndex(0);
		modeList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		controlPanel.add(modeLbl);
		controlPanel.add(modeList);

		String[] channelStrings = { "Mono(1)" };

		JLabel channelLbl = new JLabel("C (channel)", JLabel.CENTER);
		channelLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		channelList = new JComboBox(channelStrings);
		channelList.setSelectedIndex(0);
		channelList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		controlPanel.add(channelLbl);
		controlPanel.add(channelList);

		String[] sampleRateStrings = { "8000", "16000" };

		JLabel sampleRateLbl = new JLabel("R (sampleRate)", JLabel.CENTER);
		sampleRateLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sampleRateList = new JComboBox(sampleRateStrings);
		sampleRateList.setSelectedIndex(0);

		controlPanel.add(sampleRateLbl);
		controlPanel.add(sampleRateList);

		String[] sttModelCodeStrings = { "1", "2", "0" };

		JLabel sttModelCodeLbl = new JLabel(" sttModelCode ", JLabel.CENTER);
		sttModelCodeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sttModelCodeList = new JComboBox(sttModelCodeStrings);
		sttModelCodeList.setSelectedIndex(0);

		controlPanel.add(sttModelCodeLbl);
		controlPanel.add(sttModelCodeList);

		String[] sampleFmtStrings = { "S16LE" };

		JLabel sampleFmtLbl = new JLabel("F (sampleFmt)", JLabel.CENTER);
		sampleFmtLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sampleFmtList = new JComboBox(sampleFmtStrings);
		sampleFmtList.setSelectedIndex(0);
		sampleFmtList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		controlPanel.add(sampleFmtLbl);
		controlPanel.add(sampleFmtList);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));

		connectButton = new JButton("GRPC Connect");
		connectButton.setActionCommand("start");
		connectButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				taskOutput.setText("");
				mExistText = "";
				mSttgRPC.connectGRPC();
			}
		});

		disconnectButton = new JButton("GRPC Disconnect");
		disconnectButton.setActionCommand("start");
		disconnectButton.setEnabled(false);
		disconnectButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				taskOutput.setText("");
				mExistText = "";
				mSttgRPC.releaseConnection();
			}
		});

		sendFileButton = new JButton("Send AudioFile");
		sendFileButton.setActionCommand("start");
		sendFileButton.setEnabled(false);
		sendFileButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
            	mSttgRPC.setMetaData(ENV.client_key, ENV.client_id, ENV.client_secret);
				if (targetFile == null) {
					JOptionPane.showMessageDialog(panelMain, "전송할 파일을 선택 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}
				taskOutput.setText("");
				mExistText = "";
				disconnectButton.setEnabled(false);
				sendFileButton.setEnabled(false);
				int sttModelCode = Integer.parseInt((String) sttModelCodeList.getSelectedItem());
				String sttMode = (String) modeList.getSelectedItem();
				int channel = channelList.getSelectedIndex() + 1;
				String sampleFmt = (String) sampleFmtList.getSelectedItem();
				int SampleRate = Integer.parseInt((String) sampleRateList.getSelectedItem());

				mSttgRPC.startSTT(sttMode, sampleFmt, SampleRate, channel, sttModelCode);
			}
		});

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(connectButton);
		bottomPanel.add(disconnectButton);
		bottomPanel.add(sendFileButton);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(upperPanel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void SendAudioFile() {
		new Thread(new Runnable() {
			@Override
			public void run() {

				try {
					isSending = true;
					FileInputStream inputStream = new FileInputStream(targetFile);
					byte[] buffer = new byte[mSampleRate]; // 500msec 기준 0.5 * 16000(sample rate) * 16(sample format) / 8 (bits)
					int bytesRead = 0;

					while (isSending) {
						bytesRead = inputStream.read(buffer);
						if (bytesRead == -1)
							break;
						Thread.sleep(500);
						mSttgRPC.sendAudioData(buffer);
					}
					inputStream.close();

				} catch (Exception e) {
					JOptionPane.showMessageDialog(panelMain, "STT로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
				} finally {
					mSttgRPC.stopSTT();
				}
			}
		}).start();
	}
}
