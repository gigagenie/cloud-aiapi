package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Arrays;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.json.JSONArray;
import org.json.JSONObject;

import kt.gigagenie.ai.api.KTNLU;

public class KtnluRestViewer extends JFrame {
	private JPanel panelMain;
	private JPanel controlPanel;

	private JLabel mainLabel;
	private JProgressBar progressBar;
	private JButton startButton;
	private JButton NstartButton;
//	private JButton startPlay;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;
//	private JComboBox speakerList;
//	private JComboBox encodingList;
//	private JComboBox langList;
//	private JComboBox sampleRateList;
//	private JComboBox sampleFmtList;
//	private JComboBox channelList;
// ===================================
	private JComboBox domainList;
	private JComboBox freeTrialList;
// ===================================
//	private JLabel pitchLbl;
//	private JLabel speedLbl;
//	private JLabel volumeLbl;
//	private JLabel encodingLbl;
//	private JLabel langLbl;
//	private JLabel speakerLbl;
//	private JLabel sampleRateLbl;
//	private JLabel sampleFmtLbl;
//	private JLabel channelLbl;
// ===================================
	private JLabel domainLbl;
	private JLabel intentLimitLbl;
	private JLabel freeTrialLbl;
// ===================================
//	private JSlider pitchSlider;
//	private JSlider speedSlider;
//	private JSlider volumeSlider;
	private KTNLU mKtnlu = null;

	static final int LEVEL_MIN = 50;
	static final int LEVEL_MAX = 150;
	static final int LEVEL_INIT = 100;

	public KtnluRestViewer() {
		super("KTNLU Rest API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(1024, 768));
		setSize(1024, 768);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mKtnlu != null) {
					mKtnlu = null;
				}
				System.exit(0);
			}
		});

		pack();
		setVisible(true);

		if (mKtnlu == null) {
			mKtnlu = new KTNLU();
			String strUrl = "https://" + ENV.hostname + ":" + ENV.ai_api_http_port;
			mKtnlu.setServiceURL(strUrl);
			mKtnlu.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		KtnluRestViewer viewer = new KtnluRestViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		mainLabel = new JLabel("KTNLU Rest API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setToolTipText("KTNLU로 변환할 문자 입력");
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(true);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(12, 1));

		String[] domainStrings = { "1(병원 도메인)", "2(소상공인 도메인)" };

		domainLbl = new JLabel("speaker", JLabel.CENTER);
		domainLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		domainList = new JComboBox(domainStrings);
		domainList.setSelectedIndex(0);
		domainList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
			}
		});

		controlPanel.add(domainLbl);
		controlPanel.add(domainList);
		
		intentLimitLbl = new JLabel("intentLimit", JLabel.CENTER);
		intentLimitLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JTextField intentLimitText = new JTextField();

		controlPanel.add(intentLimitLbl);
		controlPanel.add(intentLimitText);
		
		String[] freeTrialStrings = { "N", "Y" };

		freeTrialLbl = new JLabel("freeTrial", JLabel.CENTER);
		freeTrialLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		freeTrialList = new JComboBox(freeTrialStrings);
		freeTrialList.setSelectedIndex(0);

		controlPanel.add(freeTrialLbl);
		controlPanel.add(freeTrialList);

//		pitchLbl = new JLabel("pitch [100]", JLabel.CENTER);
//		pitchLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		pitchSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
//		// Turn on labels at major tick marks.
//		pitchSlider.setMajorTickSpacing(50);
//		pitchSlider.setPaintTicks(true);
//		pitchSlider.setPaintLabels(true);
//		pitchSlider.addChangeListener(new ChangeListener() {
//			@Override
//			public void stateChanged(ChangeEvent e) {
//				JSlider source = (JSlider) e.getSource();
//				if (!source.getValueIsAdjusting()) {
//					int level = (int) source.getValue();
//					pitchLbl.setText("pitch [" + level + "]");
//				}
//			}
//		});
//
//		controlPanel.add(pitchLbl);
//		controlPanel.add(pitchSlider);
//
//		speedLbl = new JLabel("speed [100]", JLabel.CENTER);
//		speedLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		speedSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
//		// Turn on labels at major tick marks.
//		speedSlider.setMajorTickSpacing(50);
//		speedSlider.setPaintTicks(true);
//		speedSlider.setPaintLabels(true);
//		speedSlider.addChangeListener(new ChangeListener() {
//			@Override
//			public void stateChanged(ChangeEvent e) {
//				JSlider source = (JSlider) e.getSource();
//				if (!source.getValueIsAdjusting()) {
//					int level = (int) source.getValue();
//					speedLbl.setText("speed [" + level + "]");
//				}
//			}
//		});
//
//		controlPanel.add(speedLbl);
//		controlPanel.add(speedSlider);
//
//		volumeLbl = new JLabel("volume [100]", JLabel.CENTER);
//		volumeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		volumeSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN - 1, LEVEL_MAX, LEVEL_INIT);
//		// Turn on labels at major tick marks.
//		volumeSlider.setMajorTickSpacing(50);
//		volumeSlider.setPaintTicks(true);
//		volumeSlider.setPaintLabels(true);
//		volumeSlider.addChangeListener(new ChangeListener() {
//			@Override
//			public void stateChanged(ChangeEvent e) {
//				JSlider source = (JSlider) e.getSource();
//				if (!source.getValueIsAdjusting()) {
//					int level = (int) source.getValue();
//					volumeLbl.setText("volume [" + level + "]");
//				}
//			}
//		});
//
//		controlPanel.add(volumeLbl);
//		controlPanel.add(volumeSlider);
//
//		String[] langStrings = { "ko" };
//
//		langLbl = new JLabel("language", JLabel.CENTER);
//		langLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		langList = new JComboBox(langStrings);
//		langList.setSelectedIndex(0);
//
//		controlPanel.add(langLbl);
//		controlPanel.add(langList);
//
//		String[] sampleRateStrings = { "16000", "8000", "24000", "44100", "48000" };
//
//		sampleRateLbl = new JLabel("sampleRate", JLabel.CENTER);
//		sampleRateLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		sampleRateList = new JComboBox(sampleRateStrings);
//		sampleRateList.setSelectedIndex(0);
//
//		controlPanel.add(sampleRateLbl);
//		controlPanel.add(sampleRateList);
//
//		String[] sampleFmtStrings = { "S16LE", "F32LE" };
//
//		sampleFmtLbl = new JLabel("sampleFmt", JLabel.CENTER);
//		sampleFmtLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		sampleFmtList = new JComboBox(sampleFmtStrings);
//		sampleFmtList.setSelectedIndex(0);
//
//		controlPanel.add(sampleFmtLbl);
//		controlPanel.add(sampleFmtList);
//
//		String[] channelStrings = { "1", "2" };
//
//		channelLbl = new JLabel("channel", JLabel.CENTER);
//		channelLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		channelList = new JComboBox(channelStrings);
//		channelList.setSelectedIndex(0);
//
//		controlPanel.add(channelLbl);
//		controlPanel.add(channelList);
//
//		String[] encodingStrings = { "wav", "mp3" };
//
//		encodingLbl = new JLabel("encoding", JLabel.CENTER);
//		encodingLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
//
//		encodingList = new JComboBox(encodingStrings);
//		encodingList.setSelectedIndex(0);
//		encodingList.addActionListener(new ActionListener() {
//			@Override
//			public void actionPerformed(ActionEvent e) {
//				JComboBox cb = (JComboBox) e.getSource();
//				if (cb.getSelectedIndex() == 1) {
//					channelLbl.setVisible(false);
//					channelList.setVisible(false);
//					sampleRateLbl.setVisible(false);
//					sampleRateList.setVisible(false);
//					sampleFmtLbl.setVisible(false);
//					sampleFmtList.setVisible(false);
//				} else {
//					channelLbl.setVisible(true);
//					channelList.setVisible(true);
//					sampleRateLbl.setVisible(true);
//					sampleRateList.setVisible(true);
//					sampleFmtLbl.setVisible(true);
//					sampleFmtList.setVisible(true);
//				}
//			}
//		});

//		controlPanel.add(encodingLbl);
//		controlPanel.add(encodingList);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));
		taskOutput.setText("영업시간이 어떻게되나요?");

		startButton = new JButton("WORKSPACESERVICE Request");
//		startButton = new JButton("NERSERVICE Request");
		startButton.setActionCommand("start");
		startButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mKtnlu.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				String message = taskOutput.getText();

				progressBar.setVisible(true);

//				int pitch = pitchSlider.getValue();
//				int speed = speedSlider.getValue();
//				int speaker = speakerList.getSelectedIndex() + 1;
//				int volume = volumeSlider.getValue();
//				String language = (String) langList.getSelectedItem();
//				String encoding = (String) encodingList.getSelectedItem();
//				int channel = Integer.parseInt((String) channelList.getSelectedItem());
//				int sampleRate = Integer.parseInt((String) sampleRateList.getSelectedItem());
//				String sampleFmt = (String) sampleFmtList.getSelectedItem();
				int domain = domainList.getSelectedIndex() + 1;
				int intentLimit = Integer.parseInt((String) intentLimitText.getText());
				String freeTrial = (String) freeTrialList.getSelectedItem();

				sendText(domain, message, intentLimit, freeTrial);
			}
		});

//		progressBar = new JProgressBar();
//		progressBar.setIndeterminate(true);
//		progressBar.setVisible(false);
		
		NstartButton = new JButton("NERSERVICE Request");
//		startButton = new JButton("NERSERVICE Request");
		NstartButton.setActionCommand("start");
		NstartButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mKtnlu.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				String message = taskOutput.getText();

				progressBar.setVisible(true);

//				int pitch = pitchSlider.getValue();
//				int speed = speedSlider.getValue();
//				int speaker = speakerList.getSelectedIndex() + 1;
//				int volume = volumeSlider.getValue();
//				String language = (String) langList.getSelectedItem();
//				String encoding = (String) encodingList.getSelectedItem();
//				int channel = Integer.parseInt((String) channelList.getSelectedItem());
//				int sampleRate = Integer.parseInt((String) sampleRateList.getSelectedItem());
//				String sampleFmt = (String) sampleFmtList.getSelectedItem();
//				int domain = domainList.getSelectedIndex() + 1;
				int intentLimit = Integer.parseInt((String) intentLimitText.getText());
				String freeTrial = (String) freeTrialList.getSelectedItem();

				sendTextNERSERVICE(message, intentLimit, freeTrial);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setVisible(false);

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(startButton);
		bottomPanel.add(NstartButton);
		bottomPanel.add(progressBar);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(mainLabel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void sendText(final int domain, final String message, final int intentLimit, final String freeTrial) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {

					JSONObject resultJson = mKtnlu.requestWORKSPACESERVICE(domain, message, intentLimit, freeTrial);

					int statusCode = resultJson.optInt("statusCode");

					if (statusCode == 200) {
						String resultObject = resultJson.optString("result");
						JSONObject jsonArrayData = new JSONObject(resultObject);
						JSONArray intentArray = jsonArrayData.optJSONArray("intents");

//						JOptionPane.showMessageDialog(panelMain, a.getJSONObject(0).toString() , "결과", JOptionPane.INFORMATION_MESSAGE); // 값 하나씩
						JOptionPane.showMessageDialog(panelMain, intentArray.toString() , "결과", JOptionPane.INFORMATION_MESSAGE);	// 전체
						

						progressBar.setVisible(false);
					} else {
						progressBar.setVisible(false);

						String errorCode = resultJson.optString("errorCode");

						JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", TTS로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
					}

				} catch (Exception e) {
					JOptionPane.showMessageDialog(panelMain, e.toString() , "에러", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}).start();
	}
	
	private void sendTextNERSERVICE(final String message, final int intentLimit, final String freeTrial) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {

					JSONObject resultJson = mKtnlu.requestNERSERVICE( message, intentLimit, freeTrial);

					int statusCode = resultJson.optInt("statusCode");

					if (statusCode == 200) {
						String resultObject = resultJson.optString("result");
						JSONObject jsonArrayData = new JSONObject(resultObject);
						JSONArray intentArray = jsonArrayData.optJSONArray("intents");

//						JOptionPane.showMessageDialog(panelMain, a.getJSONObject(0).toString() , "결과", JOptionPane.INFORMATION_MESSAGE); // 값 하나씩
						JOptionPane.showMessageDialog(panelMain, intentArray.toString() , "결과", JOptionPane.INFORMATION_MESSAGE);	// 전체
						

						progressBar.setVisible(false);
					} else {
						progressBar.setVisible(false);

						String errorCode = resultJson.optString("errorCode");

						JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", TTS로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
					}

				} catch (Exception e) {
					JOptionPane.showMessageDialog(panelMain, e.toString() , "에러", JOptionPane.INFORMATION_MESSAGE);
				}
			}
		}).start();
	}
}
