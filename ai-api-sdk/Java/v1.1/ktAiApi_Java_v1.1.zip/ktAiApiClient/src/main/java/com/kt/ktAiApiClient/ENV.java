package com.kt.ktAiApiClient;

public class ENV {
//    public static final String client_key = "8eabe570-a19c-5503-8fd2-9a1d2eac4d1a";
//    public static final String client_id = "GW_TEST_CLIENT";
//    public static final String client_secret = "82fd3987e593f5779a96ae93d673cf44a7f6ed0becc9af1d4a9711fb05749b07";
//    public static final String hostname = "dev.gigagenie.ai";
//    public static final int ai_api_http_port = 55175;
//    public static final int ai_api_grpc_port = 55174; 

    
    public static final String client_key = "f94f11a0-43cc-5853-a1fa-9b32fcefa658";
    public static final String client_id = "TEST_CLIENT";
    public static final String client_secret = "39a39e67236063908d3c4e2795ddf56c2c2662a68e63922f59b2d91201e8de31";
    public static final String hostname = "tbaiapigw.gigagenie.ai";
    public static final int ai_api_http_port = 27001;
    public static final int ai_api_grpc_port = 27001; 
}
