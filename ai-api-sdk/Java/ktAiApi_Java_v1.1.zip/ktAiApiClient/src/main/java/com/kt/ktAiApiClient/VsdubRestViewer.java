package com.kt.ktAiApiClient;

import static javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
import static javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
import static javax.swing.SwingConstants.CENTER;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.JSlider;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingUtilities;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import org.json.JSONObject;

import kt.gigagenie.ai.api.VSDUB;

public class VsdubRestViewer extends JFrame {
	private JPanel panelMain;
	private JLabel mainLabel;
	private JProgressBar progressBar;
	private JButton startVSDUBButton;
	private JTextArea taskOutput;
	private JScrollPane scrollPane;

	private JComboBox emotionList;
	private JComboBox encodingList;
	private JComboBox sampleRateList;

	private JLabel speakerLbl;
	private JLabel pitchLbl;
	private JLabel speedLbl;
	private JLabel volumeLbl;
	private JLabel voiceNameLbl;
	private JLabel sampleRateLbl;

	private JLabel fileSelectLbl;
	private JFileChooser fileChooser;
	private File targetFile = null;

	private JSlider pitchSlider;
	private JSlider speedSlider;
	private JSlider volumeSlider;

	private VSDUB mVsdub = null;

	static final int LEVEL_MIN = 50;
	static final int LEVEL_MAX = 150;
	static final int LEVEL_INIT = 100;

	public VsdubRestViewer() {
		super("VSDUB Rest API DEMO");

		createUIComponents();

		JComponent newContentPane = panelMain;
		newContentPane.setOpaque(true); // content panes must be opaque
		setContentPane(newContentPane);

		setResizable(false);
		setMinimumSize(new Dimension(1024, 768));
		setSize(1024, 768);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent wEvent) {
				if (mVsdub != null) {
					mVsdub = null;
				}
				System.exit(0);
			}
		});

		pack();
		setVisible(true);

		if (mVsdub == null) {
			mVsdub = new VSDUB();
			String strUrl = "https://" + ENV.hostname + ":" + ENV.ai_api_http_port;
			mVsdub.setServiceURL(strUrl);
			mVsdub.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
		}
	}

	/**
	 * Create the GUI and show it. As with all GUI code, this must run on the event-dispatching thread.
	 */
	private static void createAndShowGUI() {
		// Create and set up the window.
		VsdubRestViewer viewer = new VsdubRestViewer();
	}

	public static void main(String[] args) {
		// Schedule a job for the event-dispatching thread:
		// creating and showing this application's GUI.
		SwingUtilities.invokeLater(() -> {
			createAndShowGUI();
		});
	}

	private void createUIComponents() {
		// Create the demo's UI.
		panelMain = new JPanel();
		fileChooser = new JFileChooser();

		mainLabel = new JLabel("VSDUB Rest API DEMO");
		mainLabel.setSize(50, 50);
		mainLabel.setHorizontalAlignment(CENTER);

		taskOutput = new JTextArea(5, 20);
		taskOutput.setToolTipText("VSDUB로 변환할 문자 입력");
		taskOutput.setMargin(new Insets(5, 5, 5, 5));
		taskOutput.setEditable(true);
		taskOutput.setCursor(null); // inherit the panel's cursor
		taskOutput.setLineWrap(true);
		taskOutput.setText("안녕하세요. 보이스 스튜디오 입니다.");

		scrollPane = new JScrollPane(taskOutput, VERTICAL_SCROLLBAR_AS_NEEDED, HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setAutoscrolls(true);

		JPanel controlPanel = new JPanel();
		controlPanel.setLayout(new GridLayout(12, 1));

		fileSelectLbl = new JLabel("Select File", JLabel.CENTER);
		fileSelectLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JButton fileButton = new JButton("Open...");
		fileButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				int returnVal = fileChooser.showOpenDialog(VsdubRestViewer.this);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					targetFile = fileChooser.getSelectedFile();

					// This is where a real application would open the file.
					fileSelectLbl.setText("File [" + targetFile.getName() + "]");
				} else {

				}
			}
		});

		controlPanel.add(fileSelectLbl);
		controlPanel.add(fileButton);

		speakerLbl = new JLabel("speaker [100~999]", JLabel.CENTER);
		speakerLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JTextField speakerText = new JTextField();
		speakerText.setText("101");

		controlPanel.add(speakerLbl);
		controlPanel.add(speakerText);

		pitchLbl = new JLabel("pitch [100]", JLabel.CENTER);
		pitchLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		pitchSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		pitchSlider.setMajorTickSpacing(50);
		pitchSlider.setPaintTicks(true);
		pitchSlider.setPaintLabels(true);
		pitchSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					pitchLbl.setText("pitch [" + level + "]");
				}
			}
		});

		controlPanel.add(pitchLbl);
		controlPanel.add(pitchSlider);

		speedLbl = new JLabel("speed [100]", JLabel.CENTER);
		speedLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		speedSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		speedSlider.setMajorTickSpacing(50);
		speedSlider.setPaintTicks(true);
		speedSlider.setPaintLabels(true);
		speedSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					speedLbl.setText("speed [" + level + "]");
				}
			}
		});

		controlPanel.add(speedLbl);
		controlPanel.add(speedSlider);

		volumeLbl = new JLabel("volume [100]", JLabel.CENTER);
		volumeLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		volumeSlider = new JSlider(JSlider.HORIZONTAL, LEVEL_MIN, LEVEL_MAX, LEVEL_INIT);
		// Turn on labels at major tick marks.
		volumeSlider.setMajorTickSpacing(50);
		volumeSlider.setPaintTicks(true);
		volumeSlider.setPaintLabels(true);
		volumeSlider.addChangeListener(new ChangeListener() {
			@Override
			public void stateChanged(ChangeEvent e) {
				JSlider source = (JSlider) e.getSource();
				if (!source.getValueIsAdjusting()) {
					int level = (int) source.getValue();
					volumeLbl.setText("volume [" + level + "]");
				}
			}
		});

		controlPanel.add(volumeLbl);
		controlPanel.add(volumeSlider);

		voiceNameLbl = new JLabel("voiceName", JLabel.CENTER);
		voiceNameLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JTextField voiceNameText = new JTextField();

		controlPanel.add(voiceNameLbl);
		controlPanel.add(voiceNameText);

		String[] emotionStrings = { "neutral", "happy", "angry", "calm", "sleepy", "sad", "excited", "fear", "disappointed" };

		JLabel emotionLbl = new JLabel("emotion", JLabel.CENTER);
		emotionLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		emotionList = new JComboBox(emotionStrings);
		emotionList.setSelectedIndex(0);

		controlPanel.add(emotionLbl);
		controlPanel.add(emotionList);

		String[] langStrings = { "ko" };

		JLabel langLbl = new JLabel("language", JLabel.CENTER);
		langLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		JComboBox langList = new JComboBox(langStrings);
		langList.setSelectedIndex(0);

		controlPanel.add(langLbl);
		controlPanel.add(langList);

		String[] encodingStrings = { "wav", "mp3" };

		JLabel encodingLbl = new JLabel("encoding", JLabel.CENTER);
		encodingLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		encodingList = new JComboBox(encodingStrings);
		encodingList.setSelectedIndex(0);

		controlPanel.add(encodingLbl);
		controlPanel.add(encodingList);

		String[] sampleRateStrings = { "16000", "8000", "44100", "48000" };

		sampleRateLbl = new JLabel("sampleRate", JLabel.CENTER);
		sampleRateLbl.setAlignmentX(Component.CENTER_ALIGNMENT);

		sampleRateList = new JComboBox(sampleRateStrings);
		sampleRateList.setSelectedIndex(0);
		sampleRateList.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {

			}
		});

		controlPanel.add(sampleRateLbl);
		controlPanel.add(sampleRateList);

		controlPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		controlPanel.setPreferredSize(new Dimension(300, 300));

		startVSDUBButton = new JButton("VSDUB Request");
		startVSDUBButton.setActionCommand("start");
		startVSDUBButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				mVsdub.setAuth(ENV.client_key, ENV.client_id, ENV.client_secret);
				String input = taskOutput.getText();

				if (targetFile == null) {
					JOptionPane.showMessageDialog(panelMain, "전송할 파일을 선택 후 요청해주세요.", "Warning", JOptionPane.WARNING_MESSAGE);
					return;
				}

				progressBar.setVisible(true);

				int speaker = Integer.parseInt(speakerText.getText());
				int pitch = pitchSlider.getValue();
				int speed = speedSlider.getValue();
				int volume = volumeSlider.getValue();
				String voiceName = "";
				String emotion = (String) emotionList.getSelectedItem();
				String language = (String) langList.getSelectedItem();
				String encoding = (String) encodingList.getSelectedItem();
				int sampleRate = Integer.parseInt((String) sampleRateList.getSelectedItem());

				SendAudioFile(input, speaker, pitch, speed, volume, language, voiceName, emotion, encoding, sampleRate);
			}
		});

		progressBar = new JProgressBar();
		progressBar.setIndeterminate(true);
		progressBar.setVisible(false);

		JPanel bottomPanel = new JPanel();
		bottomPanel.add(startVSDUBButton);
		bottomPanel.add(progressBar);

		panelMain.setLayout(new BorderLayout());
		panelMain.add(mainLabel, BorderLayout.NORTH);
		panelMain.add(scrollPane, BorderLayout.CENTER);
		panelMain.add(controlPanel, BorderLayout.EAST);
		panelMain.add(bottomPanel, BorderLayout.SOUTH);
		panelMain.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
	}

	private void SendAudioFile(final String text, final int speaker, final int pitch, final int speed, final int volume, final String language, final String voiceName, final String emotion,
			final String encoding, final int sampleRate) {
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					byte[] uploadAudioByte = null;

					FileInputStream inputStream = new FileInputStream(targetFile);
					ByteArrayOutputStream bos = new ByteArrayOutputStream();
					byte[] buffer = new byte[1024];
					int bytesRead = 0;
					while ((bytesRead = inputStream.read(buffer)) != -1) {
						bos.write(buffer, 0, bytesRead);
					}
					uploadAudioByte = bos.toByteArray();

					inputStream.close();
					bos.close();

					JSONObject resultJson = mVsdub.requestVSDUB(text, speaker, pitch, speed, volume, language, voiceName, emotion, encoding, sampleRate, uploadAudioByte);

					int statusCode = resultJson.optInt("statusCode");

					if (statusCode == 200) {
						byte[] audioData = (byte[]) resultJson.opt("audioData");

						String targetFilePath = System.getProperty("user.dir") + "\\" + "vsdub.mp3";

						FileOutputStream fos = null;
						try {
							fos = new FileOutputStream(targetFilePath);
						} catch (FileNotFoundException e) {
							e.printStackTrace();
						}

						try {
							fos.write(audioData, 0, audioData.length);
							fos.close();
							JOptionPane.showMessageDialog(panelMain, targetFilePath + "에 파일이 저장되었습니다.", "Information", JOptionPane.INFORMATION_MESSAGE);
						} catch (IOException e) {
							e.printStackTrace();
						}

						progressBar.setVisible(false);
					} else {
						progressBar.setVisible(false);

						String errorCode = resultJson.optString("errorCode");

						JOptionPane.showMessageDialog(panelMain, "statusCode:" + statusCode + ", errorCode:" + errorCode + ", VSDUB로 변환요청 중 에러가 발생하였습니다.", "Warning", JOptionPane.WARNING_MESSAGE);
					}
				} catch (Exception e) {

				}
			}
		}).start();
	}
}
