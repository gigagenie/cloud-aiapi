package com.kt.ktAiApiClient;

public class ENV {
    public static final String client_key = "client_key input";
    public static final String client_id = "client_id input";
    public static final String client_secret = "client_secret input";
    public static final String hostname = "hostname input";
    public static final int ai_api_http_port = port number input;
    public static final int ai_api_grpc_port = port number input; 
}
