config =\
    {
        'api':
        {
            'clientID':'clientID input',
            'apiKey':'apiKey input',
            'secret':'secret input',
        }
    }

class bcolors:
    HEADER = '\033[94m'
    WARNING = '\033[93m'
    ERROR = '\033[91m'
    ENDC = '\033[0m'